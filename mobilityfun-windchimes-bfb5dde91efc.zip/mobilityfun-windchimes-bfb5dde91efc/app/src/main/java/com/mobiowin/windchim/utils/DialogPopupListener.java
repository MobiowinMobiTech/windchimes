package com.mobiowin.windchim.utils;

public interface DialogPopupListener {

         void onCancelClicked(String label);
    }