package com.mobiowin.windchim.services;

import android.app.Notification;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.support.v4.app.NotificationCompat;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;
import com.mobiowin.windchim.R;
import com.mobiowin.windchim.activity.ActivityFragmentPlatform;
import com.mobiowin.windchim.db.DBAdapter;
import com.mobiowin.windchim.utils.Config;

import java.util.Calendar;
import java.util.Map;

public class NotificationRecieverService extends FirebaseMessagingService {

    private static final String TAG = NotificationRecieverService.class.getName();

    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {
        // Handle data payload of FCM messages.
        Map<String, String> notificationData = remoteMessage.getData();

        if(notificationData.size() > 0) {
            String eventId = Calendar.getInstance().getTimeInMillis()+"";

            if (notificationData.get(Config.NOTIFICATION_TYPE).equalsIgnoreCase(Config.NOTIFICATION_EVENT)){
                eventId = notificationData.get(Config.EVENT_ID);
            }

            displayNotification(notificationData.get(Config.TITLE),notificationData.get(Config.BODY),
                    notificationData.get(Config.NOTIFICATION_TYPE),eventId);

        }
    }

    private void displayNotification(String title, String body, String eventType, String eventId) {

        // Open NotificationView Class on Notification Click
        //// TODO: 4/3/17
        Intent resultIntent = new Intent(this, ActivityFragmentPlatform.class);

        DBAdapter dbAdapter = new DBAdapter(this);
        dbAdapter.open();

        String notificationBody = body;

        int notificationCount = dbAdapter.getUnreadNotificationCounts();
        if (notificationCount > 0) {
            notificationBody = "You have " + (notificationCount + 1) + " notifications from " + getString(R.string.app_name);
            title = getString(R.string.app_name);
        }

        // insert notification in local db
        dbAdapter.insertNotification(eventId,eventType,body,title);

        dbAdapter.close();

        resultIntent.putExtra(Config.NOTIFICATION_TYPE,eventType);
        resultIntent.putExtra(Config.BODY,body);
        resultIntent.putExtra(Config.EVENT_ID,eventId+"");
        resultIntent.putExtra(Config.TITLE,title);
        resultIntent.putExtra(Config.NOTIFICATION_COUNT,notificationCount);
        resultIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);

        PendingIntent pIntent = PendingIntent.getActivity(this, (int) Calendar.getInstance().getTimeInMillis(), resultIntent,0);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(this)
                .setPriority(Notification.PRIORITY_HIGH)
                .setContentTitle(title)
                .setContentIntent(pIntent)
                .setContentText(notificationBody)
                .setAutoCancel(true)
                .setDefaults(Notification.DEFAULT_SOUND);
        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            builder.setSmallIcon(R.drawable.transperent_logo);
        } else {
            builder.setSmallIcon(R.drawable.logo);
        }

        // Create Notification Manager
        android.app.NotificationManager notificationmanager = (android.app.NotificationManager)
                getSystemService(Context.NOTIFICATION_SERVICE);

        notificationmanager.cancel(0);

        // Build Notification with Notification Manager
        notificationmanager.notify(0 , builder.build());
    }
}



