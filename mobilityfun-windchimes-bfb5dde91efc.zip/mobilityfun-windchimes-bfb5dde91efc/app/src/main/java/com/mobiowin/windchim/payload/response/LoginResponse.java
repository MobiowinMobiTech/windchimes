package com.mobiowin.windchim.payload.response;

public class LoginResponse {
    private LoginResponseData[] data;
    private String message;
    private String status;

    public LoginResponseData[] getData() {
        return this.data;
    }

    public void setData(LoginResponseData[] data) {
        this.data = data;
    }

    public String getMessage() {
        return this.message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getStatus() {
        return this.status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
