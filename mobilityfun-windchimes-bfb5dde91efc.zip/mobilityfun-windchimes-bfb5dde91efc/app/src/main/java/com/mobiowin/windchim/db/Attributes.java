package com.mobiowin.windchim.db;

public class Attributes {

    public static class Database {

        public static final String DB_NAME = "windchin_database";

        public static final String PREVIOUS_EVENT_TABLE_NAME = "previous_event_table";
        public static final String EVENT_TABLE_NAME = "event_table";
        public static final String BRANCH_TABLE_NAME = "branch_table";
        public static final String PROFILE_TABLE_NAME = "profile_table";
        public static final String HOMEWORK_TABLE_NAME = "homework_table";


        public static final String EVENT_ID = "event_id";
        public static final String EVENT_TITLE = "event_title";
        public static final String EVENT_SUB_TITLE = "event_sub_title";
        public static final String EVENT_DESCRIPTION = "event_description";
        public static final String EVENT_CATEGORY = "event_category";
        public static final String EVENT_START_DATE = "event_start_date";
        public static final String EVENT_END_DATE = "event_end_date";
        public static final String EVENT_LOCATION = "event_location";
        public static final String EVENT_IS_DELETED = "event_is_deleted";
        public static final String EVENT_IMG1 = "event_img_1";
        public static final String EVENT_IMG2 = "event_img_2";
        public static final String EVENT_IMG3 = "event_img_3";
        public static final String EVENT_IMG4 = "event_img_4";

        public static final String BRANCH_ID = "branch_id";
        public static final String BRANCH_ADDRESS = "branch_address";
        public static final String LATITUDE = "latitude";
        public static final String LONGITUDE = "longitude";
        public static final String BRANCH_TYPE = "branch_type";
        public static final String EMAIL_ID = "email_id";
        public static final String MOBILE_NO = "mobile_no";
        public static final String CREATED_BY = "created_by";
        public static final String CREATED_DATE = "created_dt";
        public static final String MODIFIED_BY = "modified_by";
        public static final String MODIFIED_DATE = "modified_dt";
        public static final String DELETE_FLAG = "del_flag";

        public static final String profileId = "profile_id";
        public static final String name = "name";
        public static final String enrollmentId = "enroll_id";
        public static final String fatherName = "father_name";
        public static final String isVan = "is_vane";
        public static final String motherName = "mother_name";
        public static final String className = "class_name";
        public static final String motherNo = "mother_mob_no";
        public static final String tempAddress = "temp_address";
        public static final String fatherNo = "father_mob_no";
        public static final String date_of_birth = "dob";
        public static final String permanentAddress = "permenant_address";
        public static final String isDayBoarding = "is_day_boarding";
        public static final String date_of_joinning = "doj";



        public static final String homeworkId = "homework_id";
        public static final String homework_date = "homework_date";
        public static final String homework = "homework";
        public static final String homework_sync_date = "last_sync_date";

        public static final String CREATE_HOMEWORK_QUERY = "create table " + HOMEWORK_TABLE_NAME +
                " (" + profileId +" integer primary key autoincrement, " + enrollmentId + " text not null, " +
                homeworkId + " text not null, " + homework_date + " text not null, "
                + homework + " text , " + homework_sync_date + " text , "
                + BRANCH_ID + " text , "+ className + " text );";



        public static final String CREATE_PROFILE_QUERY = "create table " + PROFILE_TABLE_NAME +
                " (" + profileId +" integer primary key autoincrement, " + enrollmentId + " text not null, " +
                BRANCH_ID + " text not null, " + name + " text not null, "
                + fatherName + " text , " + isVan + " text , "
                + motherName + " text , "+ className + " text not null, "
                + motherNo + " text , "
                + fatherNo + " text , "+ date_of_birth + " text , "
                + tempAddress + " text , "+ isDayBoarding + " text not null, "
                + date_of_joinning + " text , "+ permanentAddress + " text );";







        public static final String CREATE_BRANCh_QUERY = "create table " + BRANCH_TABLE_NAME +
                " (_id integer primary key autoincrement, " + BRANCH_ID + " text not null, " + BRANCH_ADDRESS + " text not null, "
                + LATITUDE + " text not null, " + LONGITUDE + " text not null, "
                + BRANCH_TYPE + " text not null, "+ EMAIL_ID + " text not null, "
                + MOBILE_NO + " text not null, "+ CREATED_BY + " text not null, "
                + CREATED_DATE + " text not null, "+ MODIFIED_BY + " text not null, "
                + MODIFIED_DATE + " text not null, " + DELETE_FLAG + " text not null);";

        public static final String CREATE_EVENT_QUERY = "create table " + EVENT_TABLE_NAME +
                " (_id integer primary key autoincrement, " + EVENT_ID + " text not null, " + EVENT_IMG1 + " text , "
                + EVENT_IMG2 + " text , " + EVENT_TITLE + " text not null, "
                + EVENT_SUB_TITLE + " text not null, "+ EVENT_DESCRIPTION + " text not null, "
                + EVENT_IMG3 + " text , "+ EVENT_START_DATE + " text not null, "
                + EVENT_END_DATE + " text not null, "+ EVENT_CATEGORY + " text not null, "
                + EVENT_LOCATION + " text not null, " + EVENT_IMG4 + " text , "
                + EVENT_IS_DELETED + " text not null);";

        public static final String CREATE_PREVIOUS_EVENT_QUERY = "create table " + PREVIOUS_EVENT_TABLE_NAME +
                " (_id integer primary key autoincrement, " + EVENT_ID + " text not null, " + EVENT_IMG1 + " text , "
                + EVENT_IMG2 + " text , " + EVENT_TITLE + " text not null, "
                + EVENT_SUB_TITLE + " text not null, "+ EVENT_DESCRIPTION + " text not null, "
                + EVENT_IMG3 + " text , "+ EVENT_START_DATE + " text not null, "
                + EVENT_END_DATE + " text not null, "+ EVENT_CATEGORY + " text not null, "
                + EVENT_LOCATION + " text not null, " + EVENT_IMG4 + " text , "
                + EVENT_IS_DELETED + " text not null);";

        public static final String NOTIFICATION_TABLE_NAME = "notification_table";
        public static final String NOTIFICATION_ID = "notification_id";
        public static final String NOTIFICATION_TYPE = "notification_type";
        public static final String NOTIFICATION_MESSAGE = "notification_message";
        public static final String NOTIFICATION_TITLE = "notification_title";
        public static final String NOTIFICATION_READED = "notification_readed";

        public static final String CREATE_NOTIFICATION_QUERY = "create table " + NOTIFICATION_TABLE_NAME +
                " (_id integer primary key autoincrement, "
                + NOTIFICATION_ID + " text not null, " + NOTIFICATION_TYPE + " text not null, " +
                 NOTIFICATION_TITLE + " text not null, " +
                NOTIFICATION_MESSAGE + " text not null, "
                + NOTIFICATION_READED + " text not null);";
    }

    public static class MasterDatabase {

        public static final String MASTER_TABLE = "master_table";
        public static final String EVENT_TIMESPAN = "event_timespan";
        public static final String APP_INIT_TIMESPAN = "app_init_timespan";

        public static final String CREATE_MASTER_QUERY = "create table " + MASTER_TABLE +
                " (_id integer primary key autoincrement, " + EVENT_TIMESPAN + " text not null, "
                + APP_INIT_TIMESPAN + " text not null);";
    }


}
