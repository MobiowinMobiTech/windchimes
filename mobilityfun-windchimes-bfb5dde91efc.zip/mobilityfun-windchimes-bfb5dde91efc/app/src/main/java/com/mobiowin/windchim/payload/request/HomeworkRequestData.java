package com.mobiowin.windchim.payload.request;

public class HomeworkRequestData {
    private String branchid;
    private String classname;
    private String lastsyncdate;
    private String userid;

    public String getBranchid() {
        return this.branchid;
    }

    public void setBranchid(String branchid) {
        this.branchid = branchid;
    }

    public String getClassname() {
        return this.classname;
    }

    public void setClassname(String classname) {
        this.classname = classname;
    }

    public String getLastsyncdate() {
        return this.lastsyncdate;
    }

    public void setLastsyncdate(String lastsyncdate) {
        this.lastsyncdate = lastsyncdate;
    }

    public String getUserid() {
        return this.userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }
}
