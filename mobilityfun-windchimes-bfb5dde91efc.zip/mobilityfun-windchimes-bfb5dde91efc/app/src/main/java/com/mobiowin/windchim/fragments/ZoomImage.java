package com.mobiowin.windchim.fragments;


import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.ScaleAnimation;
import android.widget.ImageView;

import com.mobiowin.windchim.R;
import com.mobiowin.windchim.utils.CommanUtils;
import com.mobiowin.windchim.utils.Config;

@RequiresApi(api = Build.VERSION_CODES.HONEYCOMB)
public class ZoomImage extends Fragment {

    String image;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        image = getArguments().getString(Config.IMAGE_URL);
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = getActivity().getLayoutInflater().inflate(R.layout.fullscreen_image,null);

        ImageView imageView = (ImageView)view.findViewById(R.id.imageEventFullScreen);
        CommanUtils.updateImage(getActivity(),imageView,image,R.drawable.logo);

        ScaleAnimation fade_in =  new ScaleAnimation(0f, 1f, 0f, 1f, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
        fade_in.setDuration(1000);     // animation duration in milliseconds
        fade_in.setFillAfter(true);    // If fillAfter is true, the transformation that this animation performed will persist when it is finished.
        view.startAnimation(fade_in);

        return view;
    }

    
}
