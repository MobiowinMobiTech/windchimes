package com.mobiowin.windchim.utils;
public class Config {
    // global topic to receive app wide push notifications
    public static final String TOPIC_GLOBAL = "global";

    // broadcast receiver intent filters
    public static final String REGISTRATION_COMPLETE = "registrationComplete";
    public static final String PUSH_NOTIFICATION = "pushNotification";

    // id to handle the notification in the notification tray
    public static final int NOTIFICATION_ID = 100;
    public static final int NOTIFICATION_ID_BIG_IMAGE = 101;

    public static final String SHARED_PREF = "ah_firebase";
    public static final String TITLE = "title";
    public static final String BODY = "body";
    public static final String IMAGE_URL = "imageurl";
    public static final String ENTITY = "notificationentity";
    public static final String ORG_ID = "orgid";
    public static final String RECORD_ID = "recordid";
    public static final long TRIGGER_TIME = 86400000;
    public static final String APP_INIT_TIMESPAN = "AppInit";
    public static final String EVENT_TIMESPAN = "Event";
    public static final String LAST_EVENT_TIMESPAN = "LastEvent";
    public static final String BRANCH_TIMESPAN = "Branch";


    public static final String DASHBOARD_TIMESPAN = "DASHBOARD";
    public static final String LOCAL_LOGO = "localLogo";
    public static final String ACTION_UPCOMMING_EVENT = "upcommingEvent";
    public static final String ACTION_PREVIOUS_EVENT = "previousEvent";
    public static final String ACTION_BRANCH = "branch";
    public static final String NOTIFICATION_TYPE = "eventtype";
    public static final String NOTIFICATION_GENERAL = "general";
    public static final String NOTIFICATION_PRAMOTIONS = "pramotions";
    public static final String NOTIFICATION_EVENT = "event";
    public static final String EVENT_ID = "eventid";
    public static final String NOTIFICATION_BODY = "body";
    public static final String ACTION = "action";
    public static final String NOTIFICATION_COUNT = "notification_count";
    public static final String HOMEWORK_TIMESPAN = "homework";
    public static final java.lang.String HOMEWORK_ID = "homeworkId";
    public static final String HOMEWORK_DATE = "homework_date";
    public static final String HOMEWORK_DESCRIPTION = "homework_description";
}
