package com.mobiowin.windchim.db;


import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DBHelper extends SQLiteOpenHelper {

    final String TAG = DBHelper.class.getCanonicalName();

    public DBHelper(Context context, String name, CursorFactory factory,
                    int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(Attributes.MasterDatabase.CREATE_MASTER_QUERY);
        db.execSQL(Attributes.Database.CREATE_EVENT_QUERY);
        db.execSQL(Attributes.Database.CREATE_PREVIOUS_EVENT_QUERY);
        db.execSQL(Attributes.Database.CREATE_NOTIFICATION_QUERY);
        db.execSQL(Attributes.Database.CREATE_BRANCh_QUERY);
        db.execSQL(Attributes.Database.CREATE_PROFILE_QUERY);
        db.execSQL(Attributes.Database.CREATE_HOMEWORK_QUERY);
        Log.i(TAG, "Database created");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXIST " + Attributes.Database.EVENT_TABLE_NAME);
        db.execSQL("DROP TABLE IF EXIST " + Attributes.MasterDatabase.MASTER_TABLE);
        db.execSQL("DROP TABLE IF EXIST " + Attributes.Database.NOTIFICATION_TABLE_NAME);
        db.execSQL("DROP TABLE IF EXIST " + Attributes.Database.BRANCH_TABLE_NAME);
        db.execSQL("DROP TABLE IF EXIST " + Attributes.Database.PREVIOUS_EVENT_TABLE_NAME);
        db.execSQL("DROP TABLE IF EXIST " + Attributes.Database.PROFILE_TABLE_NAME);
        db.execSQL("DROP TABLE IF EXIST " + Attributes.Database.HOMEWORK_TABLE_NAME);
    }

}
