package com.mobiowin.windchim.utils;

import com.google.firebase.messaging.FirebaseMessaging;
import com.crashlytics.android.Crashlytics;
import io.fabric.sdk.android.Fabric;



public class Application extends android.app.Application {
    @Override
    public void onCreate() {
        super.onCreate();
        Fabric.with(this, new Crashlytics());

        FirebaseMessaging.getInstance().subscribeToTopic("event");
        FirebaseMessaging.getInstance().subscribeToTopic("general");
        FirebaseMessaging.getInstance().subscribeToTopic("promotions");

    }
}
