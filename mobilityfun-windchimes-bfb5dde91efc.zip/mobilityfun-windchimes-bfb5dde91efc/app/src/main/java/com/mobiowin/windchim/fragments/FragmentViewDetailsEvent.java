package com.mobiowin.windchim.fragments;

import android.database.Cursor;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridView;

import com.mobiowin.windchim.R;
import com.mobiowin.windchim.activity.ActivityFragmentPlatform;
import com.mobiowin.windchim.adapter.GridAdapter;
import com.mobiowin.windchim.customui.TextViewOpenSansRegular;
import com.mobiowin.windchim.customui.TextViewOpenSansSemiBold;
import com.mobiowin.windchim.db.Attributes;
import com.mobiowin.windchim.db.DBAdapter;
import com.mobiowin.windchim.payload.request.RequestIndDashboard;
import com.mobiowin.windchim.payload.response.ResponseIndDashboard;
import com.mobiowin.windchim.services.Device;
import com.mobiowin.windchim.services.WindchimesServices;
import com.mobiowin.windchim.utils.CommanUtils;
import com.mobiowin.windchim.utils.Config;
import com.mobiowin.windchim.utils.NetworkUtil;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;


public class FragmentViewDetailsEvent extends Fragment {

    private final static String TAG = FragmentViewDetailsEvent.class.getCanonicalName();

    private TextViewOpenSansRegular txtTitle,txtSubTitle,txtDesc,txtCategory,txtLocation,txtStartdate,
            txtEnddate;
    private TextViewOpenSansSemiBold txtStartDateDay,txtEndDateDay;

    private GridView gridEventImages;
    private ArrayList<String> eventImages;


    private DBAdapter dbAdapter;
    private String eventId, action;

    private String strTitle,strSubTitle,strDescriptions,strStartdate,strEnddate,strCategory,strLocation;
    private Cursor cursor;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_view_details_event,container,false);
        init(view);
        getPoulatedData();
        return view;
    }

    /**
     * Initialize view
     * @param view
     */
    private void init(View view) {

        eventId = getArguments().getString(Config.EVENT_ID);
        action = getArguments().getString(Config.ACTION);

        dbAdapter = new DBAdapter(getActivity());

        eventImages = new ArrayList<>();

        gridEventImages = (GridView)view.findViewById(R.id.gridEventImages);
        txtTitle = (TextViewOpenSansRegular) view.findViewById(R.id.txtTitleValue);
        txtSubTitle = (TextViewOpenSansRegular) view.findViewById(R.id.txtSubTitleValue);
        txtDesc = (TextViewOpenSansRegular) view.findViewById(R.id.txtDescValue);
        txtCategory =(TextViewOpenSansRegular)view.findViewById(R.id.txtCategoryValue);
        txtLocation =(TextViewOpenSansRegular)view.findViewById(R.id.txtLocationValue);
        txtStartdate =(TextViewOpenSansRegular)view.findViewById(R.id.txtStartDate);
        txtEnddate =(TextViewOpenSansRegular)view.findViewById(R.id.txtEndDate);

//        txtStartDateTime =(TextViewOpenSansSemiBold)view.findViewById(R.id.txtStartDateTime);
//        txtEndDateTime =(TextViewOpenSansSemiBold)view.findViewById(R.id.txtEndDateTime);

        txtStartDateDay =(TextViewOpenSansSemiBold) view.findViewById(R.id.txtStartDateDay);
        txtEndDateDay =(TextViewOpenSansSemiBold) view.findViewById(R.id.txtEndDateDay);

    }

    private void getPoulatedData() {
        dbAdapter.open();
        dbAdapter.updateNotification(eventId);
        dbAdapter.close();

        if (getArguments().getString(Config.ACTION) == null){
            getEventsFromServer();
        }else {
            updateUI();
        }

    }

    /**
     * Method used to get event from server
     */
    public void getEventsFromServer(){
        if (NetworkUtil.isInternetConnected(getActivity())) {

            CommanUtils.showDialog(getActivity());
            Device.newInstance(getActivity());

            RequestIndDashboard reqIndDash = RequestIndDashboard.get(eventId,"0");

            Retrofit mRetrofit = NetworkUtil.getRetrofit();
            WindchimesServices windchimesServices = mRetrofit.create(WindchimesServices.class);

            Call<ResponseIndDashboard> resSyncEventCall = windchimesServices.appIndDashborad(reqIndDash);

            resSyncEventCall.enqueue(new Callback<ResponseIndDashboard>() {
                @Override
                public void onResponse(Call<ResponseIndDashboard> call, Response<ResponseIndDashboard> response) {
                    if (response.isSuccessful()) {
                        if (response.body().getStatus().equals("success")) {
                            if (response.body().getData()[0].getEventlist().length > 0)
                                insertDataIntoDB(response);
                            else
                                CommanUtils.showToast(getActivity(), getResources().getString(R.string.event_not_exists));
                        }
                    } else if (response.body() == null) {
                        CommanUtils.showToast(getActivity(), getResources().getString(R.string.error_server));
                    }
                    CommanUtils.hideDialog();

                }

                @Override
                public void onFailure(Call<ResponseIndDashboard> call, Throwable t) {
                    CommanUtils.hideDialog();
                    CommanUtils.showToast(getActivity(), getResources().getString(R.string.error_timeout));
                }
            });
        } else {
            CommanUtils.showAlertDialog(getActivity(),getResources().getString(R.string.error_internet));
        }

    }

    /**
     * Function to insert data into table
     * @param response : response from server
     */
    private void insertDataIntoDB(Response<ResponseIndDashboard> response){
        dbAdapter.open();
        for (int i = 0; i < response.body().getData()[0].getEventlist().length; i++) {
            ResponseIndDashboard.Eventlist event = response.body().getData()[0].getEventlist()[i];
            action = event.getEventType();
            if (event.getEventType().equalsIgnoreCase("previous")){
                dbAdapter.insertPreviousEventInDB(event.getEventId(),event.getTitle(),event.getSubTitle(),event.getDiscription(),
                        event.getStartDt(),event.getEndDt(),event.getDeleteFlag(),event.getCategory(),event.getLocation(),
                        event.getImg1(),event.getImg2(),event.getImg3(),event.getImg4());
            }else {
                dbAdapter.insertUpcommingEventInDB(event.getEventId(),event.getTitle(),event.getSubTitle(),event.getDiscription(),
                        event.getStartDt(),event.getEndDt(),event.getDeleteFlag(),event.getCategory(),event.getLocation(),
                        event.getImg1(),event.getImg2(),event.getImg3(),event.getImg4());            }
        }

        dbAdapter.updateEventTimeSpan(response.body().getMessage());
        dbAdapter.close();
        updateUI();
    }

    /**
     * Update Event details UI
     */
    private void updateUI() {
        dbAdapter.open();
        cursor = dbAdapter.getEventById(getArguments().getString(Config.EVENT_ID),action);
        if(cursor!=null){
            cursor.moveToFirst();
            if(cursor.moveToFirst()){
                do{
                    strTitle = cursor.getString(cursor.getColumnIndex(Attributes.Database.EVENT_TITLE));
                    strSubTitle = cursor.getString(cursor.getColumnIndex(Attributes.Database.EVENT_SUB_TITLE));
                    strDescriptions = cursor.getString(cursor.getColumnIndex(Attributes.Database.EVENT_DESCRIPTION));
                    strStartdate = cursor.getString(cursor.getColumnIndex(Attributes.Database.EVENT_START_DATE));
                    strEnddate = cursor.getString(cursor.getColumnIndex(Attributes.Database.EVENT_END_DATE));
                    strCategory = cursor.getString(cursor.getColumnIndex(Attributes.Database.EVENT_CATEGORY));
                    strLocation = cursor.getString(cursor.getColumnIndex(Attributes.Database.EVENT_LOCATION));
                    if (cursor.getString(cursor.getColumnIndex(Attributes.Database.EVENT_IMG1)) != null)
                        eventImages.add(cursor.getString(cursor.getColumnIndex(Attributes.Database.EVENT_IMG1)));
                    if (cursor.getString(cursor.getColumnIndex(Attributes.Database.EVENT_IMG2)) != null)
                        eventImages.add(cursor.getString(cursor.getColumnIndex(Attributes.Database.EVENT_IMG2)));
                    if (cursor.getString(cursor.getColumnIndex(Attributes.Database.EVENT_IMG3)) != null)
                        eventImages.add(cursor.getString(cursor.getColumnIndex(Attributes.Database.EVENT_IMG3)));
                    if (cursor.getString(cursor.getColumnIndex(Attributes.Database.EVENT_IMG4)) != null)
                        eventImages.add(cursor.getString(cursor.getColumnIndex(Attributes.Database.EVENT_IMG4)));
                }while (cursor.moveToNext());
            }
        }
        dbAdapter.close();

        if (eventImages.size() > 0)
            gridEventImages.setAdapter(new GridAdapter(getActivity(),0,eventImages,getActivity().getSupportFragmentManager()));
        else
            gridEventImages.setVisibility(View.GONE);

        txtTitle.setText(strTitle);
        txtSubTitle.setText(strSubTitle);
        txtDesc.setText(strDescriptions);
        txtCategory.setText(strCategory);
        txtLocation.setText(strLocation);

        try{

            String date = getDate(strStartdate);
            String startDateArray[] = date.split(" ");
            String endDateArray[] = getDate(strEnddate).split(" ");

            txtStartDateDay.setText(startDateArray[0]);
            txtStartdate.setText(startDateArray[1]);
//            txtStartDateTime.setText(startDateArray[3].substring(0,5));

            txtEndDateDay.setText(endDateArray[0]);
            txtEnddate.setText(endDateArray[1]);
//            txtEndDateTime.setText(endDateArray[3].substring(0,5));

//            CommanUtils.hideDialog();


        }catch (Exception e){
            e.printStackTrace();
        }

    }

    /**
     * Return date in specified format.
     * @param milliSeconds Date in milliseconds
     * @return String representing date in specified format
     */
    public String getDate(String milliSeconds){
        try {
            Timestamp ts = Timestamp.valueOf(syncDateparser(milliSeconds));
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd hh:mm");
            Date fechaNueva = format.parse(ts.toString());
            format = new SimpleDateFormat("dd MMM yyyy HH:mm:ss");
            return format.format(fechaNueva);
        } catch (ParseException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return "";
    }

    public String syncDateparser(String lastSyncDate) {
        long currentDateTime = Long.parseLong(lastSyncDate);
        Date currentDate = new Date(currentDateTime);

        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        String str = dateFormat.format(currentDate);

        return str;
    }


    @Override
    public void onResume() {
        super.onResume();
        ActivityFragmentPlatform.changeToolbarTitleIcon(getResources().getString(R.string.event_details),
                R.drawable.ic_arrow_back_black_24dp);
//        getPoulatedData();
    }
}
