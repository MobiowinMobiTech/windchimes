package com.mobiowin.windchim.payload.response;

public class HomeworkResponseDataHomeworklist {
    private String deleteFlag;
    private String branchId;
    private String homeworkId;
    private String createdBy;
    private String homeworkDiscription;
    private long homeworkDt;
    private String className;
    private Object modifiedBy;
    private Object modifyDt;
    private String id;
    private long createDt;

    public String getDeleteFlag() {
        return this.deleteFlag;
    }

    public void setDeleteFlag(String deleteFlag) {
        this.deleteFlag = deleteFlag;
    }

    public String getBranchId() {
        return this.branchId;
    }

    public void setBranchId(String branchId) {
        this.branchId = branchId;
    }

    public String getHomeworkId() {
        return this.homeworkId;
    }

    public void setHomeworkId(String homeworkId) {
        this.homeworkId = homeworkId;
    }

    public String getCreatedBy() {
        return this.createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getHomeworkDiscription() {
        return this.homeworkDiscription;
    }

    public void setHomeworkDiscription(String homeworkDiscription) {
        this.homeworkDiscription = homeworkDiscription;
    }

    public long getHomeworkDt() {
        return this.homeworkDt;
    }

    public void setHomeworkDt(long homeworkDt) {
        this.homeworkDt = homeworkDt;
    }

    public String getClassName() {
        return this.className;
    }

    public void setClassName(String className) {
        this.className = className;
    }

    public Object getModifiedBy() {
        return this.modifiedBy;
    }

    public void setModifiedBy(Object modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    public Object getModifyDt() {
        return this.modifyDt;
    }

    public void setModifyDt(Object modifyDt) {
        this.modifyDt = modifyDt;
    }

    public String getId() {
        return this.id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public long getCreateDt() {
        return this.createDt;
    }

    public void setCreateDt(long createDt) {
        this.createDt = createDt;
    }
}
