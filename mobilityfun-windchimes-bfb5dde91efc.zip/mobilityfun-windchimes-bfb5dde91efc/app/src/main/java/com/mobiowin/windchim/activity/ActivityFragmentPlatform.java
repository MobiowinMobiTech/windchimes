package com.mobiowin.windchim.activity;

import android.animation.Animator;
import android.animation.ValueAnimator;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.mobiowin.windchim.R;
import com.mobiowin.windchim.customui.RoundedImageView;
import com.mobiowin.windchim.customui.TextViewOpenSansRegular;
import com.mobiowin.windchim.customui.TextViewOpenSansSemiBold;
import com.mobiowin.windchim.db.Attributes;
import com.mobiowin.windchim.db.DBAdapter;
import com.mobiowin.windchim.fragments.FragmentAboutUs;
import com.mobiowin.windchim.fragments.FragmentConnectWithUs;
import com.mobiowin.windchim.fragments.FragmentDashboard;
import com.mobiowin.windchim.fragments.FragmentFacilities;
import com.mobiowin.windchim.fragments.FragmentHomework;
import com.mobiowin.windchim.fragments.FragmentNotifications;
import com.mobiowin.windchim.fragments.FragmentStudentDashboard;
import com.mobiowin.windchim.fragments.FragmentTimeTable;
import com.mobiowin.windchim.fragments.FragmentViewDetailsEvent;
import com.mobiowin.windchim.fragments.FragmentViewEventAndBranches;
import com.mobiowin.windchim.fragments.NotificationOther;
import com.mobiowin.windchim.fragments.StudentProfile;
import com.mobiowin.windchim.payload.request.RequestIndDashboard;
import com.mobiowin.windchim.payload.response.ResponseIndDashboard;
import com.mobiowin.windchim.services.Device;
import com.mobiowin.windchim.services.WindchimesServices;
import com.mobiowin.windchim.utils.CommanUtils;
import com.mobiowin.windchim.utils.Config;
import com.mobiowin.windchim.utils.DialogPopupListener;
import com.mobiowin.windchim.utils.NetworkUtil;
import com.mobiowin.windchim.utils.PreferenceUtils;
import com.mobiowin.windchim.utils.Social;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class ActivityFragmentPlatform extends AppCompatActivity implements View.OnClickListener,
        DialogPopupListener {

    private static final String TAG = ActivityFragmentPlatform.class.getSimpleName();

    private static DrawerLayout mDrawerLayout;
    private static LinearLayout mDrawerList;

    private Fragment fragment;
    private static RoundedImageView IMG_PROFILE;
    private static TextView TXT_USER_NAME;
    private static PreferenceUtils PREF;
    private static DBAdapter DB_ADAPTER;

    String enrollmentId, branchId;

    private View viewDrawer;

    private LinearLayout llDrawerHolder;

    private TextViewOpenSansRegular txtUpcommingEvent, txtPreviousEvents, txtBranches, txtFacilities,
                                    txtConnectWithUs, txtAboutUs, txtEvents,txtSignIn;


    private LinearLayout eventContainer;
    private ValueAnimator mAnimatorEventContainer;

    private static Toolbar TOOLBAR;
    private static boolean IS_LAST = true;
    private static AppCompatActivity _CONTEXT;

//    private AdView mAdView;
//    private ViewGroup adContainer;

    private static ImageView IMG_NOTIFICATION, imgSignIn;
    private static TextViewOpenSansSemiBold TOOLBAR_TITLE;
    private static TextViewOpenSansSemiBold NOTIFICATION_COUNT;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        CommanUtils.setNewUserStatus(this,false);

        initSideDrawer();
        initComponents();

    }


    /**
     * Method used to initialize components
     */
    private void initComponents() {
        _CONTEXT = this;
        PREF = new PreferenceUtils(ActivityFragmentPlatform.this);
        DB_ADAPTER = new DBAdapter(ActivityFragmentPlatform.this);
        llDrawerHolder = (LinearLayout) findViewById(R.id.llDrawerHolder);

        launchDashboard();

        //// TODO: 5/3/17  notification code
            try {
                Bundle notificationData = getIntent().getExtras();

                String entity = notificationData.getString(Config.NOTIFICATION_TYPE);
                if(!entity.equalsIgnoreCase("") || entity != null){
                    if (notificationData.getInt(Config.NOTIFICATION_COUNT) > 1){
                        getFragmentTransaction(this,new FragmentNotifications());
                    }else{
                        if (entity.equalsIgnoreCase(Config.NOTIFICATION_EVENT)) {
                            setRetrofitRequest(notificationData.getString(Config.EVENT_ID));
                        }
                        else
                            openOtherNotification(getIntent());
                    }

                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
    }

    /**
     * Function to open notification of type general and pramotions
     * @param intent
     */
    private void openOtherNotification(Intent intent) {
        fragment = new NotificationOther();
        Bundle bundle = new Bundle();
        bundle.putString(Config.TITLE,intent.getExtras().getString(Config.TITLE));
        bundle.putString(Config.BODY,intent.getExtras().getString(Config.BODY));
        bundle.putString(Config.EVENT_ID,intent.getExtras().getString(Config.EVENT_ID));
        fragment.setArguments(bundle);
        getFragmentTransaction(ActivityFragmentPlatform.this,fragment);
    }

    /**
     * Function to launch dashboard
     */
    private void launchDashboard(){

        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        if (PREF.isLoggedIn()){

            enrollmentId = getIntent().getExtras().getString(Attributes.Database.enrollmentId);
            branchId = getIntent().getExtras().getString(Attributes.Database.BRANCH_ID);

            imgSignIn.setVisibility(View.INVISIBLE);
            initializingStudentDrawerComponants();
            Bundle bundle = new Bundle();
            bundle.putString(Attributes.Database.enrollmentId,enrollmentId);
            bundle.putString(Attributes.Database.BRANCH_ID,branchId);
            FragmentStudentDashboard fragmentStudentDashboard = new FragmentStudentDashboard();
            fragmentStudentDashboard.setArguments(bundle);
            transaction.replace(R.id.platform, fragmentStudentDashboard);
        }else {
            imgSignIn.setVisibility(View.VISIBLE);
            initializingIndDrawerComponants();
            transaction.replace(R.id.platform, new FragmentDashboard());
        }

        transaction.addToBackStack(null);
        transaction.commit();
    }

    /**
     * Function used to initialise student drawer
     */
    private void initializingStudentDrawerComponants() {
        LayoutInflater inflater= (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        viewDrawer = inflater.inflate(R.layout.student_drawer, null);
        llDrawerHolder.removeView(viewDrawer);
        llDrawerHolder.addView(viewDrawer);

        TextViewOpenSansRegular txtProfile, txtHomework, txtTimeTable, txtResult, txtLogout;
        txtProfile = (TextViewOpenSansRegular)viewDrawer.findViewById(R.id.txtProfile);
        txtHomework = (TextViewOpenSansRegular)viewDrawer.findViewById(R.id.txtHomework);
        txtResult = (TextViewOpenSansRegular)viewDrawer.findViewById(R.id.txtResult);
        txtTimeTable = (TextViewOpenSansRegular)viewDrawer.findViewById(R.id.txtTimetable);
        txtLogout = (TextViewOpenSansRegular)viewDrawer.findViewById(R.id.txtLogout);

        txtProfile.setOnClickListener(this);
        txtHomework.setOnClickListener(this);
        txtResult.setOnClickListener(this);
        txtTimeTable.setOnClickListener(this);
        txtLogout.setOnClickListener(this);

    }

    /**
     * Initialize slider and drawer
     */
    private void initSideDrawer() {

        mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        mDrawerList = (LinearLayout) findViewById(R.id.left_drawer);

        IMG_NOTIFICATION = (ImageView) findViewById(R.id.action_notification);
        imgSignIn = (ImageView) findViewById(R.id.action_signin);
        NOTIFICATION_COUNT = (TextViewOpenSansSemiBold) findViewById(R.id.action_count);
        TOOLBAR_TITLE = (TextViewOpenSansSemiBold) findViewById(R.id.txtDashTitle);

        IMG_NOTIFICATION.setOnClickListener(this);
        imgSignIn.setOnClickListener(this);

        TOOLBAR = (Toolbar) findViewById(R.id.toolbar);
        TOOLBAR.setTitle("");
        setSupportActionBar(TOOLBAR);

        //Profile image
        IMG_PROFILE = (RoundedImageView) findViewById(R.id.img_user_profile);
        TXT_USER_NAME = (TextView) findViewById(R.id.textView2);

        IMG_PROFILE.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (PREF.isLoggedIn())
                    viewProfile();
            }
        });


    }

    private void viewProfile() {
        Bundle bundle = new Bundle();
        bundle.putString(Attributes.Database.enrollmentId,enrollmentId);
        bundle.putString(Attributes.Database.BRANCH_ID,branchId);
        StudentProfile studentProfile = new StudentProfile();
        studentProfile.setArguments(bundle);
        getFragmentTransaction(this,studentProfile);
    }

    /**
     * Function to change title bar
     * @param title : Title to change
     * @param icon : icon to display ie hamberger menu
     */
    public static void changeToolbarTitleIcon(String title,int icon) {

        if (TOOLBAR != null) {
            TOOLBAR_TITLE.setText(title);
            TOOLBAR.setNavigationIcon(icon);

            if(_CONTEXT!=null){
                IS_LAST = title.equals(_CONTEXT.getString(R.string.dash_borad)) ? true : false;
            }

            int notification_donate_IconVisibility =
                (title.equals(_CONTEXT.getString(R.string.dash_borad)))
                 ? View.VISIBLE : View.GONE;
            IMG_NOTIFICATION.setVisibility(notification_donate_IconVisibility);

            DB_ADAPTER.open();
            int count = DB_ADAPTER.getUnreadNotificationCounts();
            DB_ADAPTER.close();
            NOTIFICATION_COUNT.setText(""+count);

            int notificationCountVisibility = (count > 0 && notification_donate_IconVisibility==View.VISIBLE)
                    ? View.VISIBLE : View.GONE;
            NOTIFICATION_COUNT.setVisibility(notificationCountVisibility);

        }
    }

    @RequiresApi(api = Build.VERSION_CODES.HONEYCOMB)
    private void expand(LinearLayout linearLayout, ValueAnimator valueAnimator) {
        // set Visible
        linearLayout.setVisibility(View.VISIBLE);
        valueAnimator.start();
    }

    @RequiresApi(api = Build.VERSION_CODES.HONEYCOMB)
    private void collapse(final LinearLayout linearLayout) {
        int finalHeight = linearLayout.getHeight();

        ValueAnimator mAnimator = slideAnimator(linearLayout,finalHeight, 0);

        mAnimator.addListener(new Animator.AnimatorListener() {
            @Override
            public void onAnimationEnd(Animator animator) {
                // Height=0, but it set visibility to GONE
                linearLayout.setVisibility(View.GONE);
            }

            @Override
            public void onAnimationStart(Animator animator) {
            }

            @Override
            public void onAnimationCancel(Animator animator) {
            }

            @Override
            public void onAnimationRepeat(Animator animator) {
            }
        });
        mAnimator.start();
    }

    @RequiresApi(api = Build.VERSION_CODES.HONEYCOMB)
    private ValueAnimator slideAnimator(final LinearLayout linearLayout,int start, int end) {

        ValueAnimator animator = ValueAnimator.ofInt(start, end);

        animator.addUpdateListener(new     ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator valueAnimator) {
                // Update Height
                int value = (Integer) valueAnimator.getAnimatedValue();

                ViewGroup.LayoutParams layoutParams = linearLayout
                        .getLayoutParams();
                layoutParams.height = value;
                linearLayout.setLayoutParams(layoutParams);
            }
        });
        return animator;
    }

    private static void getFragmentTransaction(final FragmentActivity context, Fragment fragment){

        context.getSupportFragmentManager().beginTransaction()
                .replace(R.id.platform, fragment)
                .addToBackStack(""+fragment.getTag()).commit();

        if (mDrawerLayout.isDrawerOpen(mDrawerList)) {
            mDrawerLayout.closeDrawers();
        }
    }


    @Override
    public void onBackPressed() {
        if (mDrawerLayout.isDrawerOpen(GravityCompat.START)) {
            mDrawerLayout.closeDrawer(GravityCompat.START);
        } else if (getSupportFragmentManager().findFragmentById(R.id.platform) instanceof FragmentDashboard) {
            showExitAlert();
        } else if (getSupportFragmentManager().findFragmentById(R.id.platform) instanceof FragmentStudentDashboard) {
            showExitAlert();
        } else{
            super.onBackPressed();
        }
    }

    /**
     * Function to display exit app dialogue with options
     */
    private void showExitAlert(){
        AlertDialog.Builder alertBuilder = new AlertDialog.Builder(this);
        alertBuilder.setTitle(getString(R.string.app_name));
        alertBuilder.setMessage(getString(R.string.exit_app_message));
        alertBuilder.setIcon(R.drawable.logo);
        alertBuilder.setCancelable(false);
        alertBuilder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                PREF.setLoggedInStatus(false);
                finish();
            }
        });
        alertBuilder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

            }
        });
        alertBuilder.show();
    }


    @Override
    protected void onResume() {
        super.onResume();
        _CONTEXT = this;

        getProfileUpdate();


    }

    /**
     * Function to get profile image from sp
     */
    public void getProfileUpdate(){
        if (PREF.isLoggedIn()) {
            Bitmap profilePic = CommanUtils.getUserProfile(this, Social.ENTITY_STUDENT);
            if (profilePic != null)
                IMG_PROFILE.setImageBitmap(profilePic);

            if (PREF.getUserName() != null) {
                TXT_USER_NAME.setText(PREF.getUserName());
            }
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                if(IS_LAST){
                    if(mDrawerLayout.isDrawerOpen(GravityCompat.START))
                        mDrawerLayout.closeDrawers();  // CLOSE DRAWER
                    else
                        mDrawerLayout.openDrawer(GravityCompat.START);  // OPEN DRAWER

                }else{
                    onBackPressed();
                }

               return true;
        }
        return super.onOptionsItemSelected(item);
    }

    /**
     * Method to exit from app if user do not give location permission to fetching the location
     * @param context
     */
    public static void getFinished(FragmentActivity context){
        context.finish();
    }


    /**
     * Method to defining the side drawer for individual login
     */
    private void initializingIndDrawerComponants() {

        LayoutInflater inflater= (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        viewDrawer = inflater.inflate(R.layout.individual_drawer, null);
        llDrawerHolder.removeView(viewDrawer);
        llDrawerHolder.addView(viewDrawer);


        txtEvents = (TextViewOpenSansRegular)viewDrawer.findViewById(R.id.txtEvent);

        txtUpcommingEvent = (TextViewOpenSansRegular)viewDrawer.findViewById(R.id.txtUpcommingEvent);
        txtPreviousEvents = (TextViewOpenSansRegular)viewDrawer.findViewById(R.id.txtPreviousEvent);
        txtAboutUs = (TextViewOpenSansRegular)viewDrawer.findViewById(R.id.txtAboutUs);
        txtConnectWithUs = (TextViewOpenSansRegular)viewDrawer.findViewById(R.id.txtContact);
        txtBranches = (TextViewOpenSansRegular)viewDrawer.findViewById(R.id.txtBranches);
        txtFacilities = (TextViewOpenSansRegular)viewDrawer.findViewById(R.id.txtFacilities);
        txtSignIn = (TextViewOpenSansRegular)viewDrawer.findViewById(R.id.txtSignIn);

        txtFacilities.setOnClickListener(this);
        txtBranches.setOnClickListener(this);
        txtAboutUs.setOnClickListener(this);
        txtConnectWithUs.setOnClickListener(this);
        txtPreviousEvents.setOnClickListener(this);
        txtUpcommingEvent.setOnClickListener(this);
        txtEvents.setOnClickListener(this);
        txtSignIn.setOnClickListener(this);

        eventContainer = (LinearLayout)viewDrawer.findViewById(R.id.txtContainerEvent);


        eventContainer.getViewTreeObserver().addOnPreDrawListener(
                new ViewTreeObserver.OnPreDrawListener() {

                    @RequiresApi(api = Build.VERSION_CODES.HONEYCOMB)
                    @Override
                    public boolean onPreDraw() {
                        eventContainer.getViewTreeObserver()
                                .removeOnPreDrawListener(this);
                        eventContainer.setVisibility(View.GONE);

                        final int widthSpec =     View.MeasureSpec.makeMeasureSpec(
                                0, View.MeasureSpec.UNSPECIFIED);
                        final int heightSpec = View.MeasureSpec
                                .makeMeasureSpec(0,
                                        View.MeasureSpec.UNSPECIFIED);
                        eventContainer.measure(widthSpec, heightSpec);

                        mAnimatorEventContainer = slideAnimator(eventContainer,0,
                                eventContainer.getMeasuredHeight());
                        return true;
                    }
                });

    }

    @RequiresApi(api = Build.VERSION_CODES.HONEYCOMB)
    @Override
    public void onClick(View v) {
        Fragment fragment = getSupportFragmentManager().findFragmentById(R.id.platform);
        Bundle bundle;
        DB_ADAPTER.open();
        switch (v.getId()){
            case R.id.txtEvent:
                if (eventContainer.getVisibility() == View.GONE) {
                    expand(eventContainer,mAnimatorEventContainer);
                } else {
                    collapse(eventContainer);
                }
                break;

            case R.id.txtUpcommingEvent:
                if (DB_ADAPTER.getAllUpcommingEvent("F").getCount() > 0) {
                    bundle = new Bundle();
                    bundle.putString("action", Config.ACTION_UPCOMMING_EVENT);
                    bundle.putString("title", getString(R.string.upcomming_event));
                    viewEventAndBranchList(bundle);
                    closeDrawer();
                }else
                    CommanUtils.showToast(getApplicationContext(),getString(R.string.upcomming_event_not_found));
                break;

            case R.id.txtPreviousEvent:
                if (DB_ADAPTER.getAllPreviousEvents("F").getCount() > 0) {
                    bundle = new Bundle();
                    bundle.putString("action", Config.ACTION_PREVIOUS_EVENT);
                    bundle.putString("title", getString(R.string.previous_event));
                    viewEventAndBranchList(bundle);
                    closeDrawer();
                }else
                    CommanUtils.showToast(getApplicationContext(),getString(R.string.previous_event_not_found));
                break;

            case R.id.txtBranches:
                if (DB_ADAPTER.getAllBranches("F").getCount() > 0) {
                    bundle = new Bundle();
                    bundle.putString("action", Config.ACTION_BRANCH);
                    bundle.putString("title", getString(R.string.branches));
                    viewEventAndBranchList(bundle);
                    closeDrawer();
                }else
                    CommanUtils.showToast(getApplicationContext(),getString(R.string.branches_not_found));
                break;

            case R.id.txtFacilities:
                if(!(fragment instanceof FragmentFacilities)) {
                    getFragmentTransaction(ActivityFragmentPlatform.this,new FragmentFacilities());
                }
                break;

            case R.id.txtAboutUs:
                if(!(fragment instanceof FragmentAboutUs)) {
                    getFragmentTransaction(ActivityFragmentPlatform.this,new FragmentAboutUs());
                }
                break;

            case R.id.txtContact:
                if(!(fragment instanceof FragmentConnectWithUs)) {
                    getFragmentTransaction(ActivityFragmentPlatform.this,new FragmentConnectWithUs());
                }
                break;

            case R.id.action_notification:
                getFragmentTransaction(ActivityFragmentPlatform.this,new FragmentNotifications());
                break;

            case R.id.action_signin :
                startActivity(new Intent(ActivityFragmentPlatform.this,Login.class));
                finish();
                closeDrawer();
                break;

            case R.id.txtSignIn:
                closeDrawer();
                startActivity(new Intent(ActivityFragmentPlatform.this,Login.class));
                break;

            case R.id.txtHomework:
                if(!(fragment instanceof FragmentHomework)) {
                    FragmentHomework fragmentHomework = new FragmentHomework();
                    bundle = new Bundle();
                    bundle.putString(Attributes.Database.enrollmentId,enrollmentId);
                    bundle.putString(Attributes.Database.BRANCH_ID,branchId);
                    fragmentHomework.setArguments(bundle);
                    getFragmentTransaction(ActivityFragmentPlatform.this,fragmentHomework);
                }
                break;

            case R.id.txtProfile:
                viewProfile();
                break;

            case R.id.txtResult:
                break;

            case R.id.txtTimetable:
                if(!(fragment instanceof FragmentTimeTable)) {
                    FragmentTimeTable fragmentTimeTable = new FragmentTimeTable();
                    bundle = new Bundle();
                    bundle.putString(Attributes.Database.enrollmentId,enrollmentId);
                    bundle.putString(Attributes.Database.BRANCH_ID,branchId);
                    fragmentTimeTable.setArguments(bundle);
                    getFragmentTransaction(ActivityFragmentPlatform.this,fragmentTimeTable);
                }
                break;

            case R.id.txtLogout:
                PREF.setLoggedInStatus(false);
                try {
                    llDrawerHolder.removeView(viewDrawer);
                }catch (Exception ex){

                }
                launchDashboard();
                closeDrawer();
                break;


        }

        DB_ADAPTER.close();
    }

    /**
     * Function to open event and branch list when drawer menu clickes
     * @param bundle : bundle to pass fro list
     */
    private void viewEventAndBranchList(Bundle bundle) {

        FragmentViewEventAndBranches fragmentViewEvent = new FragmentViewEventAndBranches();
        fragmentViewEvent.setArguments(bundle);

        getFragmentTransaction(ActivityFragmentPlatform.this,fragmentViewEvent);
    }

    /**
     * Function used to close drawer
     */
    private void closeDrawer() {
        if (mDrawerLayout.isDrawerOpen(GravityCompat.START)) {
            mDrawerLayout.closeDrawer(GravityCompat.START);
        }
    }


    @Override
    public void onCancelClicked(String label) {
        onBackPressed();
    }

    /**
     * Function used to get event details based on event id
     * @param eventId event id
     */
    public void setRetrofitRequest(String eventId) {
        if (NetworkUtil.isInternetConnected(ActivityFragmentPlatform.this)) {
            Device.newInstance(ActivityFragmentPlatform.this);
            RequestIndDashboard reqIndDash = RequestIndDashboard.get(eventId,"0");

            Retrofit mRetrofit = NetworkUtil.getRetrofit();
            WindchimesServices windchimesServices = mRetrofit.create(WindchimesServices.class);

            Call<ResponseIndDashboard> resSyncEventCall = windchimesServices.appIndDashborad(reqIndDash);

            resSyncEventCall.enqueue(new Callback<ResponseIndDashboard>() {
                @Override
                public void onResponse(Call<ResponseIndDashboard> call, Response<ResponseIndDashboard> response) {
                    if (response.isSuccessful()) {
                        if (response.body().getStatus().equals("success")) {
                            insertDataIntoDB(response);
                            viewEvent(response);
                        }
                    } else if (response.body() == null) {
                        CommanUtils.showToast(ActivityFragmentPlatform.this, getResources().getString(R.string.error_server));
                    }
                }

                @Override
                public void onFailure(Call<ResponseIndDashboard> call, Throwable t) {
                    CommanUtils.hideDialog();
                }
            });
        } else {
            CommanUtils.showAlertDialog(ActivityFragmentPlatform.this,getResources().getString(R.string.error_internet));
        }
    }

    /**
     * Function to open event details page
     * @param response : response from server
     */
    private void viewEvent(Response<ResponseIndDashboard> response) {
        if (response.body().getData()[0].getEventlist().length > 0){
            ResponseIndDashboard.Eventlist event = response.body().getData()[0].getEventlist()[0];
            String action = event.getEventType();
            fragment = new FragmentViewDetailsEvent();
            Bundle bundle = new Bundle();
            bundle.putString(Config.ACTION,action.equalsIgnoreCase("previous") ? Config.ACTION_PREVIOUS_EVENT : Config.ACTION_UPCOMMING_EVENT);
            bundle.putString(Config.EVENT_ID,event.getEventId());
            fragment.setArguments(bundle);

            getFragmentTransaction(ActivityFragmentPlatform.this,fragment);
        }else
            CommanUtils.showToast(this, getResources().getString(R.string.event_not_exists));

    }

    /**
     * Function to insert data into table
     * @param response : response from server
     */
    private void insertDataIntoDB(Response<ResponseIndDashboard> response){

        DB_ADAPTER.open();

        for (int i = 0; i < response.body().getData()[0].getEventlist().length; i++) {
            ResponseIndDashboard.Eventlist event = response.body().getData()[0].getEventlist()[i];

            if (event.getEventType().equalsIgnoreCase("previous")){
                DB_ADAPTER.insertPreviousEventInDB(event.getEventId(),event.getTitle(),event.getSubTitle(),event.getDiscription(),
                        event.getStartDt(),event.getEndDt(),event.getDeleteFlag(),event.getCategory(),event.getLocation(),
                        event.getImg1(),event.getImg2(),event.getImg3(),event.getImg4());
            }else {
                DB_ADAPTER.insertUpcommingEventInDB(event.getEventId(),event.getTitle(),event.getSubTitle(),event.getDiscription(),
                        event.getStartDt(),event.getEndDt(),event.getDeleteFlag(),event.getCategory(),event.getLocation(),
                        event.getImg1(),event.getImg2(),event.getImg3(),event.getImg4());            }
        }

        DB_ADAPTER.close();
    }


}
