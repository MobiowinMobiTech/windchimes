package com.mobiowin.windchim.payload.response;

public class ResponseInitialData {
    private String message;

    private String status;

    private Data[] data;

    public String getMessage ()
    {
        return message;
    }

    public void setMessage (String message)
    {
        this.message = message;
    }

    public String getStatus ()
    {
        return status;
    }

    public void setStatus (String status)
    {
        this.status = status;
    }

    public Data[] getData ()
    {
        return data;
    }

    public void setData (Data[] data)
    {
        this.data = data;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [message = "+message+", status = "+status+", data = "+data+"]";
    }

    public class Data
    {
        private Bannerlist[] bannerlist;

        private Branchlist[] branchlist;

        private String lastsyncdate;

        private Broadcasttopiclist[] broadcasttopiclist;

        public Broadcasttopiclist[] getBroadcasttopiclist() {
            return broadcasttopiclist;
        }

        public void setBroadcasttopiclist(Broadcasttopiclist[] broadcasttopiclist) {
            this.broadcasttopiclist = broadcasttopiclist;
        }

        public Bannerlist[] getBannerlist ()
        {
            return bannerlist;
        }

        public void setBannerlist (Bannerlist[] bannerlist)
        {
            this.bannerlist = bannerlist;
        }

        public Branchlist[] getBranchlist ()
        {
            return branchlist;
        }

        public void setBranchlist (Branchlist[] branchlist)
        {
            this.branchlist = branchlist;
        }

        public String getLastsyncdate ()
        {
            return lastsyncdate;
        }

        public void setLastsyncdate (String lastsyncdate)
        {
            this.lastsyncdate = lastsyncdate;
        }



        @Override
        public String toString()
        {
            return "ClassPojo [bannerlist = "+bannerlist+", branchlist = "+branchlist+", lastsyncdate = "+lastsyncdate+", broadcasttopiclist = "+broadcasttopiclist+"]";
        }
    }


    public class Bannerlist
    {
        private String id;

        private String others;

        private String createdBy;

        private String location;

        private String modifiedBy;

        private String bannerLink;

        private String bannerName;

        private String bannerId;

        private String discription;

        private String deleteFlag;

        private String modifyDt;

        private String createDt;

        public String getId ()
        {
            return id;
        }

        public void setId (String id)
        {
            this.id = id;
        }

        public String getOthers ()
        {
            return others;
        }

        public void setOthers (String others)
        {
            this.others = others;
        }

        public String getCreatedBy ()
        {
            return createdBy;
        }

        public void setCreatedBy (String createdBy)
        {
            this.createdBy = createdBy;
        }

        public String getLocation ()
        {
            return location;
        }

        public void setLocation (String location)
        {
            this.location = location;
        }

        public String getModifiedBy ()
    {
        return modifiedBy;
    }

        public void setModifiedBy (String modifiedBy)
        {
            this.modifiedBy = modifiedBy;
        }

        public String getBannerLink ()
        {
            return bannerLink;
        }

        public void setBannerLink (String bannerLink)
        {
            this.bannerLink = bannerLink;
        }

        public String getBannerName ()
        {
            return bannerName;
        }

        public void setBannerName (String bannerName)
        {
            this.bannerName = bannerName;
        }

        public String getBannerId ()
        {
            return bannerId;
        }

        public void setBannerId (String bannerId)
        {
            this.bannerId = bannerId;
        }

        public String getDiscription ()
        {
            return discription;
        }

        public void setDiscription (String discription)
        {
            this.discription = discription;
        }

        public String getDeleteFlag ()
        {
            return deleteFlag;
        }

        public void setDeleteFlag (String deleteFlag)
        {
            this.deleteFlag = deleteFlag;
        }

        public String getModifyDt ()
    {
        return modifyDt;
    }

        public void setModifyDt (String modifyDt)
        {
            this.modifyDt = modifyDt;
        }

        public String getCreateDt ()
        {
            return createDt;
        }

        public void setCreateDt (String createDt)
        {
            this.createDt = createDt;
        }

        @Override
        public String toString()
        {
            return "ClassPojo [id = "+id+", others = "+others+", createdBy = "+createdBy+", location = "+location+", modifiedBy = "+modifiedBy+", bannerLink = "+bannerLink+", bannerName = "+bannerName+", bannerId = "+bannerId+", discription = "+discription+", deleteFlag = "+deleteFlag+", modifyDt = "+modifyDt+", createDt = "+createDt+"]";
        }
    }


    public class Branchlist
    {
        private String id;

        private String emailId;

        private String createdBy;

        private String address;

        private String branchId;

        private String modifiedBy;

        private String branchType;

        private String longitude;

        private String latitude;

        private String deleteFlag;

        private String modifyDt;

        private String createDt;

        private String mobileNo;

        public String getId ()
        {
            return id;
        }

        public void setId (String id)
        {
            this.id = id;
        }

        public String getEmailId ()
        {
            return emailId;
        }

        public void setEmailId (String emailId)
        {
            this.emailId = emailId;
        }

        public String getCreatedBy ()
        {
            return createdBy;
        }

        public void setCreatedBy (String createdBy)
        {
            this.createdBy = createdBy;
        }

        public String getAddress ()
        {
            return address;
        }

        public void setAddress (String address)
        {
            this.address = address;
        }

        public String getBranchId ()
        {
            return branchId;
        }

        public void setBranchId (String branchId)
        {
            this.branchId = branchId;
        }

        public String getModifiedBy ()
        {
            return modifiedBy;
        }

        public void setModifiedBy (String modifiedBy)
        {
            this.modifiedBy = modifiedBy;
        }

        public String getBranchType ()
        {
            return branchType;
        }

        public void setBranchType (String branchType)
        {
            this.branchType = branchType;
        }

        public String getLongitude ()
    {
        return longitude;
    }

        public void setLongitude (String longitude)
        {
            this.longitude = longitude;
        }

        public String getLatitude ()
    {
        return latitude;
    }

        public void setLatitude (String latitude)
        {
            this.latitude = latitude;
        }

        public String getDeleteFlag ()
        {
            return deleteFlag;
        }

        public void setDeleteFlag (String deleteFlag)
        {
            this.deleteFlag = deleteFlag;
        }

        public String getModifyDt ()
        {
            return modifyDt;
        }

        public void setModifyDt (String modifyDt)
        {
            this.modifyDt = modifyDt;
        }

        public String getCreateDt ()
        {
            return createDt;
        }

        public void setCreateDt (String createDt)
        {
            this.createDt = createDt;
        }

        public String getMobileNo ()
        {
            return mobileNo;
        }

        public void setMobileNo (String mobileNo)
        {
            this.mobileNo = mobileNo;
        }

        @Override
        public String toString()
        {
            return "ClassPojo [id = "+id+", emailId = "+emailId+", createdBy = "+createdBy+", address = "+address+", branchId = "+branchId+", modifiedBy = "+modifiedBy+", branchType = "+branchType+", longitude = "+longitude+", latitude = "+latitude+", deleteFlag = "+deleteFlag+", modifyDt = "+modifyDt+", createDt = "+createDt+", mobileNo = "+mobileNo+"]";
        }
    }


    public class Broadcasttopiclist
    {
        private String id;

        private String others;

        private String createdBy;

        private String broadcastTopic;

        private String modifiedBy;

        private String discription;

        private String broadcastName;

        private String broadcastId;

        private String deleteFlag;

        private String modifyDt;

        private String createDt;

        public String getId ()
        {
            return id;
        }

        public void setId (String id)
        {
            this.id = id;
        }

        public String getOthers ()
    {
        return others;
    }

        public void setOthers (String others)
        {
            this.others = others;
        }

        public String getCreatedBy ()
        {
            return createdBy;
        }

        public void setCreatedBy (String createdBy)
        {
            this.createdBy = createdBy;
        }

        public String getBroadcastTopic ()
        {
            return broadcastTopic;
        }

        public void setBroadcastTopic (String broadcastTopic)
        {
            this.broadcastTopic = broadcastTopic;
        }

        public String getModifiedBy ()
        {
            return modifiedBy;
        }

        public void setModifiedBy (String modifiedBy)
        {
            this.modifiedBy = modifiedBy;
        }

        public String getDiscription ()
        {
            return discription;
        }

        public void setDiscription (String discription)
        {
            this.discription = discription;
        }

        public String getBroadcastName ()
        {
            return broadcastName;
        }

        public void setBroadcastName (String broadcastName)
        {
            this.broadcastName = broadcastName;
        }

        public String getBroadcastId ()
        {
            return broadcastId;
        }

        public void setBroadcastId (String broadcastId)
        {
            this.broadcastId = broadcastId;
        }

        public String getDeleteFlag ()
        {
            return deleteFlag;
        }

        public void setDeleteFlag (String deleteFlag)
        {
            this.deleteFlag = deleteFlag;
        }

        public String getModifyDt ()
        {
            return modifyDt;
        }

        public void setModifyDt (String modifyDt)
        {
            this.modifyDt = modifyDt;
        }

        public String getCreateDt ()
        {
            return createDt;
        }

        public void setCreateDt (String createDt)
        {
            this.createDt = createDt;
        }

        @Override
        public String toString()
        {
            return "ClassPojo [id = "+id+", others = "+others+", createdBy = "+createdBy+", broadcastTopic = "+broadcastTopic+", modifiedBy = "+modifiedBy+", discription = "+discription+", broadcastName = "+broadcastName+", broadcastId = "+broadcastId+", deleteFlag = "+deleteFlag+", modifyDt = "+modifyDt+", createDt = "+createDt+"]";
        }
    }





}
