package com.mobiowin.windchim.fragments;

import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.mobiowin.windchim.R;
import com.mobiowin.windchim.activity.ActivityFragmentPlatform;
import com.mobiowin.windchim.customui.TextViewOpenSansSemiBold;
import com.mobiowin.windchim.db.Attributes;
import com.mobiowin.windchim.db.DBAdapter;

public class FragmentTimeTable extends Fragment {

    String className;

    DBAdapter dbAdapter;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        String enrollmentId = getArguments().getString(Attributes.Database.enrollmentId);
        String branchId = getArguments().getString(Attributes.Database.BRANCH_ID);

        dbAdapter = new DBAdapter(getActivity());

        dbAdapter.open();

        className = dbAdapter.getClassNameOfStudent(enrollmentId,branchId);

    }

    @Override
    public View onCreateView(LayoutInflater inflater,  ViewGroup container, Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_time_table,null);

        TextViewOpenSansSemiBold txtDataNotFound = (TextViewOpenSansSemiBold)view.findViewById(R.id.txtDataNotFound);
        ImageView imgTimeTable = (ImageView)view.findViewById(R.id.imageTimeTable);

        Log.d("", "onCreateView:classname:"+className);


        if (className == null) {
            txtDataNotFound.setVisibility(View.VISIBLE);
            imgTimeTable.setVisibility(View.GONE);
        }else {
            txtDataNotFound.setVisibility(View.GONE);
            String uri = "@drawable/"+className.toLowerCase();
            try {
                int imageResource = getResources().getIdentifier(uri, null, getActivity().getPackageName());
                Drawable res = getResources().getDrawable(imageResource);
                imgTimeTable.setImageDrawable(res);
            }catch (Exception ex){
                txtDataNotFound.setVisibility(View.VISIBLE);
                imgTimeTable.setVisibility(View.GONE);
            }
        }
        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        ActivityFragmentPlatform.changeToolbarTitleIcon(getResources().getString(R.string.time_table),
                R.drawable.ic_arrow_back_black_24dp);
    }
}
