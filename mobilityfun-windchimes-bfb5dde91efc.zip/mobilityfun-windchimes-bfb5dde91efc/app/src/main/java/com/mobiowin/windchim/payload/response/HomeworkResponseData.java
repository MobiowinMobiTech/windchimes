package com.mobiowin.windchim.payload.response;

public class HomeworkResponseData {
    private HomeworkResponseDataHomeworklist[] homeworklist;
    private long lastsyncdate;

    public HomeworkResponseDataHomeworklist[] getHomeworklist() {
        return this.homeworklist;
    }

    public void setHomeworklist(HomeworkResponseDataHomeworklist[] homeworklist) {
        this.homeworklist = homeworklist;
    }

    public long getLastsyncdate() {
        return this.lastsyncdate;
    }

    public void setLastsyncdate(long lastsyncdate) {
        this.lastsyncdate = lastsyncdate;
    }
}
