package com.mobiowin.windchim.fragments;

import android.database.Cursor;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;

import com.mobiowin.windchim.R;
import com.mobiowin.windchim.activity.ActivityFragmentPlatform;
import com.mobiowin.windchim.adapter.NotificationListsAdapter;
import com.mobiowin.windchim.customui.TextViewOpenSansRegular;
import com.mobiowin.windchim.db.Attributes;
import com.mobiowin.windchim.db.DBAdapter;
import com.mobiowin.windchim.utils.Config;

public class FragmentNotifications extends Fragment {

    private static final String TAG = FragmentNotifications.class.getSimpleName();
    private ListView listView;
    private TextViewOpenSansRegular txtNoData;
    private String[] listOfIds;
    private String[] listOfMessages;
    private String[] listOfTypes;
    private String[] listOfReaded;

    private int counter = 0;

    private DBAdapter dbAdapter;


    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_notification, null, false);

        setHasOptionsMenu(true);

        initializingComponents(view);
        return view;
    }


    @RequiresApi(api = Build.VERSION_CODES.HONEYCOMB)
    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        inflater.inflate(R.menu.notification_menu,menu);
        menu.getItem(0).setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.menuDeleteNotification){
            dbAdapter.open();
            dbAdapter.deleteAllNotifications();
            dbAdapter.close();

            getAllNotificationsFromDB();
        }

        return true;

    }

    /**
     * Initialize components
     * @param view : view
     */
    private void initializingComponents(View view) {

        dbAdapter = new DBAdapter(getActivity());

        listView = (ListView) view.findViewById(R.id.listView);
        txtNoData = (TextViewOpenSansRegular) view.findViewById(R.id.txtDataNotFound);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                Fragment fragment = null;
                Bundle bundle = new Bundle();
                bundle.putString(Config.TITLE,listOfTypes[position]);
                bundle.putString(Config.BODY,listOfMessages[position]);
                bundle.putString(Config.EVENT_ID,listOfIds[position]);
                if (listOfTypes[position].equalsIgnoreCase(Config.NOTIFICATION_EVENT)) {
                    fragment = new FragmentViewDetailsEvent();
                    fragment.setArguments(bundle);
                    getActivity().getSupportFragmentManager().beginTransaction().
                            replace(R.id.platform, fragment).addToBackStack(null).commit();

                }else {
                    fragment = new NotificationOther();
                    fragment.setArguments(bundle);
                    getActivity().getSupportFragmentManager().beginTransaction().
                            replace(R.id.platform, fragment).addToBackStack(null).commit();
                }
            }
        });
    }


    /**
     * Get data fromlocal database
     */
    public void getAllNotificationsFromDB(){

        dbAdapter.open();
        Cursor cursor = dbAdapter.getAllNotification();

        listOfIds =new String[cursor.getCount()];
        listOfMessages =new String[cursor.getCount()];
        listOfTypes =new String[cursor.getCount()];
        listOfReaded =new String[cursor.getCount()];
        if(cursor !=null){
            cursor.moveToFirst();
            if(cursor.moveToFirst()){
                do{
                    listOfIds[counter] = (cursor.getString(cursor.getColumnIndex(Attributes.Database.NOTIFICATION_ID)));
                    listOfMessages[counter] = (cursor.getString(cursor.getColumnIndex(Attributes.Database.NOTIFICATION_MESSAGE)));
                    listOfTypes[counter] = (cursor.getString(cursor.getColumnIndex(Attributes.Database.NOTIFICATION_TYPE)));
                    listOfReaded[counter] = (cursor.getString(cursor.getColumnIndex(Attributes.Database.NOTIFICATION_READED)));
                    counter = counter+1;
                }while(cursor.moveToNext());
            }
        }
        counter=0;
        dbAdapter.close();

        if(listOfIds!=null && listOfIds.length>0 ) {
            listView.setAdapter(new NotificationListsAdapter(getActivity(), 0, listOfTypes,listOfMessages,listOfReaded));
            listView.setVisibility(View.VISIBLE);
            txtNoData.setVisibility(View.GONE);
        }else{
            listView.setVisibility(View.GONE);
            txtNoData.setVisibility(View.VISIBLE);
        }

    }


    @Override
    public void onResume() {
        super.onResume();
        ActivityFragmentPlatform.changeToolbarTitleIcon(getResources().getString(R.string.notification),
                R.drawable.ic_arrow_back_black_24dp);
        getAllNotificationsFromDB();
    }
}
