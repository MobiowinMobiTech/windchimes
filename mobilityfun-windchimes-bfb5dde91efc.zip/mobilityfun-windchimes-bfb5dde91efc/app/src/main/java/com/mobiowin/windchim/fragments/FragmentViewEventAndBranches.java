package com.mobiowin.windchim.fragments;

import android.database.Cursor;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;

import com.mobiowin.windchim.R;
import com.mobiowin.windchim.activity.ActivityFragmentPlatform;
import com.mobiowin.windchim.adapter.ListsAdapter;
import com.mobiowin.windchim.customui.TextViewOpenSansRegular;
import com.mobiowin.windchim.db.Attributes;
import com.mobiowin.windchim.db.DBAdapter;
import com.mobiowin.windchim.utils.Config;
import com.mobiowin.windchim.utils.PreferenceUtils;


public class FragmentViewEventAndBranches extends Fragment {

    private static final String TAG = FragmentViewEventAndBranches.class.getCanonicalName();
    private ListView listView;
    private TextViewOpenSansRegular txtNoData;
    private String[] listOfEventIds;
    private String[] listOfEventTitles;
    private String[] listOfEventSubTitles;
    private String[] listStartDate;

    private int counter = 0;
    private String title, action;
    private DBAdapter dbAdapter;
    private PreferenceUtils pref;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_list_view, null, false);
        init(view);

        return view;
    }

    /**
     * Initialize view
     * @param view
     */
    private void init(View view) {

        Bundle bundle = getArguments();
        title = bundle.getString("title");
        action = bundle.getString(Config.ACTION);

        dbAdapter = new DBAdapter(getActivity());
        pref = new PreferenceUtils(getActivity());

        listView = (ListView) view.findViewById(R.id.listView);
        txtNoData = (TextViewOpenSansRegular) view.findViewById(R.id.txtDataNotFound);
        txtNoData.setText(getString(R.string.event_not_found));

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            if (!action.equalsIgnoreCase(Config.ACTION_BRANCH)){
                FragmentViewDetailsEvent fragmentViewDetailsEvent = new FragmentViewDetailsEvent();
                Bundle bundle = new Bundle();
                bundle.putString(Config.ACTION,action);
                bundle.putString(Config.EVENT_ID,listOfEventIds[position]);
                fragmentViewDetailsEvent.setArguments(bundle);
                getActivity().getSupportFragmentManager().beginTransaction().
                        replace(R.id.platform, fragmentViewDetailsEvent).addToBackStack(null).commit();
            }else {
                FragmentBranchDetail fragmentBranchDetail = new FragmentBranchDetail();
                Bundle bundle = new Bundle();
                bundle.putString("branchId",listOfEventIds[position]);
                fragmentBranchDetail.setArguments(bundle);
                getActivity().getSupportFragmentManager().beginTransaction().
                        replace(R.id.platform, fragmentBranchDetail).addToBackStack(null).commit();

            }

            }
        });

    }

    /**
     * Function to get all data from local db
     */
    public void getDatafromLocalDb() {

        dbAdapter.open();

        Cursor cursor = null;
        // get data from local DB according to
        if (action.equalsIgnoreCase(Config.ACTION_UPCOMMING_EVENT))
         cursor = dbAdapter.getAllUpcommingEvent("F");
        else if (action.equalsIgnoreCase(Config.ACTION_PREVIOUS_EVENT))
            cursor = dbAdapter.getAllPreviousEvents("F");
        else if (action.equalsIgnoreCase(Config.ACTION_BRANCH))
            cursor = dbAdapter.getAllBranches("F");

        listOfEventIds = new String[cursor.getCount()];
        listOfEventTitles = new String[cursor.getCount()];
        listOfEventSubTitles = new String[cursor.getCount()];
        listStartDate = new String[cursor.getCount()];

        if (action.equalsIgnoreCase(Config.ACTION_BRANCH)){
            if (cursor != null) {
                cursor.moveToFirst();
                if (cursor.moveToFirst()) {
                    do {
                        listOfEventIds[counter] = (cursor.getString(cursor.getColumnIndex(Attributes.Database.BRANCH_ID)));
                        listOfEventTitles[counter] = (getString(R.string.app_name));
                        listOfEventSubTitles[counter] = (cursor.getString(cursor.getColumnIndex(Attributes.Database.BRANCH_ADDRESS)));
                        listStartDate[counter] = "";
                        counter = counter + 1;
                    } while (cursor.moveToNext());
                }
            }
        }else {
            if (cursor != null) {
                cursor.moveToFirst();
                if (cursor.moveToFirst()) {
                    do {
                        listOfEventIds[counter] = (cursor.getString(cursor.getColumnIndex(Attributes.Database.EVENT_ID)));
                        listOfEventTitles[counter] = (cursor.getString(cursor.getColumnIndex(Attributes.Database.EVENT_TITLE)));
                        listOfEventSubTitles[counter] = (cursor.getString(cursor.getColumnIndex(Attributes.Database.EVENT_SUB_TITLE)));
                        listStartDate[counter] = (cursor.getString(cursor.getColumnIndex(Attributes.Database.EVENT_START_DATE)));
                        counter = counter + 1;
                    } while (cursor.moveToNext());
                }
            }
        }

        counter = 0;
        dbAdapter.close();

        if(listOfEventTitles!=null && listOfEventTitles.length>0 ) {
            if (action.equalsIgnoreCase(Config.ACTION_BRANCH))
                listView.setAdapter(new ListsAdapter(getActivity(), 1, listOfEventTitles,listOfEventSubTitles,listStartDate));
            else
                listView.setAdapter(new ListsAdapter(getActivity(), 0, listOfEventTitles,listOfEventSubTitles,listStartDate));

            listView.setVisibility(View.VISIBLE);
            txtNoData.setVisibility(View.GONE);
        }else{
            listView.setVisibility(View.GONE);
            txtNoData.setVisibility(View.VISIBLE);
        }

    }



    @Override
    public void onResume() {
        super.onResume();
        ActivityFragmentPlatform.changeToolbarTitleIcon(title,R.drawable.ic_arrow_back_black_24dp);
        getDatafromLocalDb();
    }
}
