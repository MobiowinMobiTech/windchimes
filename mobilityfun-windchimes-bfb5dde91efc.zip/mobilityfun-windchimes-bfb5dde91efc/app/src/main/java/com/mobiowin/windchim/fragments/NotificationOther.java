package com.mobiowin.windchim.fragments;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.mobiowin.windchim.R;
import com.mobiowin.windchim.activity.ActivityFragmentPlatform;
import com.mobiowin.windchim.customui.TextViewOpenSansRegular;
import com.mobiowin.windchim.customui.TextViewOpenSansSemiBold;
import com.mobiowin.windchim.db.DBAdapter;
import com.mobiowin.windchim.utils.Config;


public class NotificationOther extends Fragment{
    String title, message, id;


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle bundle = getArguments();
        title = bundle.getString(Config.TITLE);
        message = bundle.getString(Config.BODY);
        id = bundle.getString(Config.EVENT_ID);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View notificationView = inflater.inflate(R.layout.fragment_notification_other,null);

        TextViewOpenSansRegular txtTitle = (TextViewOpenSansRegular)notificationView.findViewById(R.id.txtTitle);
        TextViewOpenSansSemiBold txtMessage = (TextViewOpenSansSemiBold)notificationView.findViewById(R.id.txtMessage);

        txtTitle.setText(title);
        txtMessage.setText(message);

        DBAdapter dbAdapter =new DBAdapter(getActivity());
        dbAdapter.open();
        dbAdapter.updateNotification(id);
        dbAdapter.close();


        return notificationView;
    }

    @Override
    public void onResume() {
        super.onResume();
        ActivityFragmentPlatform.changeToolbarTitleIcon(title,R.drawable.ic_arrow_back_black_24dp);
    }
}
