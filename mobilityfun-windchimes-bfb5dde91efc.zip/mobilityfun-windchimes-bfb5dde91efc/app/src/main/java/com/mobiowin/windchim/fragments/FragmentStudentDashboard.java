package com.mobiowin.windchim.fragments;

import android.database.Cursor;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.CardView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.mobiowin.windchim.R;
import com.mobiowin.windchim.activity.ActivityFragmentPlatform;
import com.mobiowin.windchim.adapter.SlidingImageAdapter;
import com.mobiowin.windchim.db.Attributes;
import com.mobiowin.windchim.db.DBAdapter;
import com.mobiowin.windchim.helper.CircleIndicator;
import com.mobiowin.windchim.payload.request.HomeworkRequest;
import com.mobiowin.windchim.payload.request.HomeworkRequestData;
import com.mobiowin.windchim.payload.response.HomeworkResponse;
import com.mobiowin.windchim.payload.response.HomeworkResponseDataHomeworklist;
import com.mobiowin.windchim.services.WindchimesServices;
import com.mobiowin.windchim.utils.CommanUtils;
import com.mobiowin.windchim.utils.NetworkUtil;
import com.mobiowin.windchim.utils.PreferenceUtils;
import com.mobiowin.windchim.utils.Social;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class FragmentStudentDashboard extends Fragment implements View.OnClickListener {

    private ViewPager mPager;
    private CircleIndicator mCircleIndicator;
    private DBAdapter dbAdapter;
    private PreferenceUtils pref;
    private String enrollmentId, branchId;
    private String[] images;
    private Handler handler = new Handler();
    private Runnable refresh;
    private int itemPos = 0;
    private SlidingImageAdapter slidingImageAdapter;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_student_dashboard, container, false);
        init(view);
        handlingSlideShow();
        return view;
    }

    private void init(View view) {
        dbAdapter = new DBAdapter(getActivity());
        pref = new PreferenceUtils(getActivity());
        pref.setLoggedInStatus(false);
        enrollmentId = getArguments().getString(Attributes.Database.enrollmentId);
        branchId = getArguments().getString(Attributes.Database.BRANCH_ID);

        mPager = (ViewPager) view.findViewById(R.id.image_pager);
        mCircleIndicator = (CircleIndicator) view.findViewById(R.id.indicator);

        CardView txtHomeWork, txtTimetable, txtResults;
        txtHomeWork = (CardView)view.findViewById(R.id.txtHomework);
        txtTimetable = (CardView)view.findViewById(R.id.txtTimetable);
        txtResults = (CardView)view.findViewById(R.id.txtResult);

        txtHomeWork.setOnClickListener(this);
        txtTimetable.setOnClickListener(this);
        txtResults.setOnClickListener(this);

    }

    @RequiresApi(api = Build.VERSION_CODES.HONEYCOMB)
    private void handlingSlideShow() {
        if(!pref.getBanners().isEmpty()){
            images = pref.getBanners().split("~");
        }else{
            images = new String[3];
            for(int i=0;i<3;i++){
                images[i] = "www.error.com";
            }
        }

        slidingImageAdapter =new SlidingImageAdapter(getActivity(), images);
        mPager.setAdapter(slidingImageAdapter);
        mCircleIndicator.setViewPager(mPager);
    }

    public void initializeTimer(){
        itemPos = mPager.getCurrentItem();
        if(handler!=null){
            handler.removeCallbacks(refresh);
        }

        handler = new Handler();

        refresh = new Runnable() {
            public void run() {
                if (mPager.getCurrentItem() < images.length-1) {
                    mPager.setCurrentItem(itemPos, true);
                    itemPos = itemPos + 1;
                }else{
                    itemPos = 0;
                    mPager.setCurrentItem(itemPos, true);
                }
                handler.postDelayed(refresh, 4000);
            }
        };
        handler.post(refresh);
    }



    @Override
    public void onResume() {
        super.onResume();
        ActivityFragmentPlatform.changeToolbarTitleIcon(getResources().getString(R.string.dash_borad),
                R.drawable.ic_menu_black_24dp);
        // existing data
        getAllHomeworkFromServer();
        // slider image timmer
        initializeTimer();
    }

    /**
     * Function to get all homework from server
     */
    private void getAllHomeworkFromServer() {
        if (NetworkUtil.isInternetConnected(getActivity())) {
            dbAdapter.open();
            Cursor cursor = dbAdapter.getUserDetailsForHomework(enrollmentId,branchId);
            Log.d("", "getHomeworks: HM COUNT:"+cursor.getCount());
            String classname = null, lastSync = "0";

            if (cursor != null) {
                cursor.moveToFirst();
                if (cursor.moveToFirst()) {
                    do {
                        classname = (cursor.getString(cursor.getColumnIndex(Attributes.Database.className)));
                        lastSync = (cursor.getString(cursor.getColumnIndex(Attributes.Database.homework_sync_date)));
                        if (lastSync == null)
                            lastSync = "0";
                        Log.d("", "getAllHomeworkFromServer: "+lastSync);
                    } while (cursor.moveToNext());
                }
            }

            dbAdapter.close();

            Log.d("", "getHomeworks: "+branchId);
            Log.d("", "getHomeworks: "+classname);
            Log.d("", "getHomeworks: "+lastSync);

            HomeworkRequest homeworkRequest = new HomeworkRequest();
            homeworkRequest.setType(Social.HOMEWORK_TYPE);
            homeworkRequest.setAction(Social.ACTION_SYNC_TYPE);
            homeworkRequest.setEntity(Social.ENTITY_STUDENT);

            HomeworkRequestData homeworkRequestData = new HomeworkRequestData();
            homeworkRequestData.setBranchid(branchId);
            homeworkRequestData.setClassname(classname);
            homeworkRequestData.setLastsyncdate(lastSync);
            homeworkRequestData.setUserid(enrollmentId);

            homeworkRequest.setData(homeworkRequestData);


            Retrofit mRetrofit = NetworkUtil.getRetrofit();
            WindchimesServices windchimesServices = mRetrofit.create(WindchimesServices.class);
            final Call<HomeworkResponse> getHomeworkService = windchimesServices.getHomework(homeworkRequest);
            getHomeworkService.enqueue(new Callback<HomeworkResponse>() {
                @Override
                public void onResponse(Call<HomeworkResponse> call, Response<HomeworkResponse> response) {
                    if (response.body().getStatus().equalsIgnoreCase("success")) {
                        insertHomework(response.body().getData()[0].getHomeworklist(),response.body().getData()[0].getLastsyncdate());
                    }
                }

                @Override
                public void onFailure(Call<HomeworkResponse> call, Throwable t) {

                }
            });


        }else {
            CommanUtils.showToast(getActivity(),getString(R.string.first_time_user_without_network));
        }
    }

    /**
     * Function to save all home work into local db
     * @param homeworklist : homeworks
     * @param lastsyncdate : last sync date
     */
    private void insertHomework(HomeworkResponseDataHomeworklist[] homeworklist, long lastsyncdate) {
        dbAdapter.open();
        for (int index = 0 ; index < homeworklist.length; index++){
            HomeworkResponseDataHomeworklist homework = homeworklist[index];
            dbAdapter.insertHomework(lastsyncdate,homework.getBranchId(),homework.getClassName(),homework.getHomeworkDiscription(),
                    homework.getHomeworkDt(),homework.getHomeworkId(),enrollmentId);
        }
        dbAdapter.close();
    }


    @Override
    public void onClick(View v) {
        Bundle bundle;
        switch (v.getId()){
            case R.id.txtHomework:
                FragmentHomework fragmentHomework = new FragmentHomework();
                bundle = new Bundle();
                bundle.putString(Attributes.Database.enrollmentId,enrollmentId);
                bundle.putString(Attributes.Database.BRANCH_ID,branchId);
                fragmentHomework.setArguments(bundle);
                getActivity().getSupportFragmentManager().beginTransaction().
                        replace(R.id.platform, fragmentHomework).addToBackStack(null).commit();
                break;
            case R.id.txtTimetable:

                FragmentTimeTable fragmentTimeTable = new FragmentTimeTable();
                bundle = new Bundle();
                bundle.putString(Attributes.Database.enrollmentId,enrollmentId);
                bundle.putString(Attributes.Database.BRANCH_ID,branchId);
                fragmentTimeTable.setArguments(bundle);
                getActivity().getSupportFragmentManager().beginTransaction().
                        replace(R.id.platform, fragmentTimeTable).addToBackStack(null).commit();

                break;
            case R.id.txtResult:
                break;
        }
    }
}
