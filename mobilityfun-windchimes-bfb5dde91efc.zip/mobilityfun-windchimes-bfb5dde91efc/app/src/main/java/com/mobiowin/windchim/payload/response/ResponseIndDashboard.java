package com.mobiowin.windchim.payload.response;

import java.util.Arrays;

public class ResponseIndDashboard {


    private String message;

    private String status;

    private Data[] data;

    public String getMessage ()
    {
        return message;
    }

    public void setMessage (String message)
    {
        this.message = message;
    }

    public String getStatus ()
    {
        return status;
    }

    public void setStatus (String status)
    {
        this.status = status;
    }

    public Data[] getData ()
    {
        return data;
    }

    public void setData (Data[] data)
    {
        this.data = data;
    }

    @Override
    public String toString() {
        return "ResponseIndDashboard{" +
                "message='" + message + '\'' +
                ", status='" + status + '\'' +
                ", data=" + Arrays.toString(data) +
                '}';
    }



    public class Data
    {

        private Eventlist[] eventlist;

        private String lastsyncdate;

        public Eventlist[] getEventlist ()
        {
            return eventlist;
        }

        public void setEventlist (Eventlist[] eventlist)
        {
            this.eventlist = eventlist;
        }

        public String getLastsyncdate ()
        {
            return lastsyncdate;
        }

        public void setLastsyncdate (String lastsyncdate)
        {
            this.lastsyncdate = lastsyncdate;
        }

        @Override
        public String toString() {
            return "Data{" +
                    "eventlist=" + Arrays.toString(eventlist) +
                    ", lastsyncdate='" + lastsyncdate + '\'' +
                    '}';
        }
    }

    public class Eventlist
    {
        private String img2;

        private String img1;

        private String location;

        private String endDt;

        private String modifiedBy;

        private String discription;

        private String eventType;

        private String id;

        private String subTitle;

        private String title;

        private String category;

        private String createdBy;

        private String eventId;

        private String startDt;

        private String deleteFlag;

        private String modifyDt;

        private String createDt;

        private String img3;

        private String img4;

        public String getImg2 ()
        {
            return img2;
        }

        public void setImg2 (String img2)
        {
            this.img2 = img2;
        }

        public String getImg1 ()
        {
            return img1;
        }

        public void setImg1 (String img1)
        {
            this.img1 = img1;
        }

        public String getLocation ()
        {
            return location;
        }

        public void setLocation (String location)
        {
            this.location = location;
        }

        public String getEndDt ()
        {
            return endDt;
        }

        public void setEndDt (String endDt)
        {
            this.endDt = endDt;
        }

        public String getModifiedBy ()
        {
            return modifiedBy;
        }

        public void setModifiedBy (String modifiedBy)
        {
            this.modifiedBy = modifiedBy;
        }

        public String getDiscription ()
        {
            return discription;
        }

        public void setDiscription (String discription)
        {
            this.discription = discription;
        }

        public String getEventType ()
        {
            return eventType;
        }

        public void setEventType (String eventType)
        {
            this.eventType = eventType;
        }

        public String getId ()
        {
            return id;
        }

        public void setId (String id)
        {
            this.id = id;
        }

        public String getSubTitle ()
        {
            return subTitle;
        }

        public void setSubTitle (String subTitle)
        {
            this.subTitle = subTitle;
        }

        public String getTitle ()
        {
            return title;
        }

        public void setTitle (String title)
        {
            this.title = title;
        }

        public String getCategory ()
        {
            return category;
        }

        public void setCategory (String category)
        {
            this.category = category;
        }

        public String getCreatedBy ()
        {
            return createdBy;
        }

        public void setCreatedBy (String createdBy)
        {
            this.createdBy = createdBy;
        }

        public String getEventId ()
        {
            return eventId;
        }

        public void setEventId (String eventId)
        {
            this.eventId = eventId;
        }

        public String getStartDt ()
        {
            return startDt;
        }

        public void setStartDt (String startDt)
        {
            this.startDt = startDt;
        }

        public String getDeleteFlag ()
        {
            return deleteFlag;
        }

        public void setDeleteFlag (String deleteFlag)
        {
            this.deleteFlag = deleteFlag;
        }

        public String getModifyDt ()
        {
            return modifyDt;
        }

        public void setModifyDt (String modifyDt)
        {
            this.modifyDt = modifyDt;
        }

        public String getCreateDt ()
        {
            return createDt;
        }

        public void setCreateDt (String createDt)
        {
            this.createDt = createDt;
        }

        public String getImg3 ()
        {
            return img3;
        }

        public void setImg3 (String img3)
        {
            this.img3 = img3;
        }

        public String getImg4 ()
        {
            return img4;
        }

        public void setImg4 (String img4)
        {
            this.img4 = img4;
        }

        @Override
        public String toString()
        {
            return "ClassPojo [img2 = "+img2+", img1 = "+img1+", location = "+location+", endDt = "+endDt+", modifiedBy = "+modifiedBy+", discription = "+discription+", eventType = "+eventType+", id = "+id+", subTitle = "+subTitle+", title = "+title+", category = "+category+", createdBy = "+createdBy+", eventId = "+eventId+", startDt = "+startDt+", deleteFlag = "+deleteFlag+", modifyDt = "+modifyDt+", createDt = "+createDt+", img3 = "+img3+", img4 = "+img4+"]";
        }
    }


}
