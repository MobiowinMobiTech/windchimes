package com.mobiowin.windchim.fragments;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.mobiowin.windchim.R;
import com.mobiowin.windchim.customui.TextViewOpenSansRegular;
import com.mobiowin.windchim.customui.TextViewOpenSansSemiBold;
import com.mobiowin.windchim.utils.Config;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class FragmentHomeworkDetails extends Fragment {
    String homeworkDate, homeworkDescription;
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        homeworkDate = getArguments().getString(Config.HOMEWORK_DATE);
        homeworkDescription = getArguments().getString(Config.HOMEWORK_DESCRIPTION);

    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_notification_other,null);

        TextViewOpenSansRegular txtTitle = (TextViewOpenSansRegular)view.findViewById(R.id.txtTitle);
        TextViewOpenSansSemiBold txtMessage = (TextViewOpenSansSemiBold)view.findViewById(R.id.txtMessage);


        String[] date = getDate(homeworkDate).split(" ");

        txtTitle.setText(date[0]+" "+date[1]+" "+date[2]);

        txtMessage.setText("");
        arrangeHomeworkList(txtMessage);

        return view;
    }

    /**
     * Arrange homework
     * split by , and display as indexing
     * @param txtMessage
     */
    private void arrangeHomeworkList(TextViewOpenSansSemiBold txtMessage) {

        String[] homeworks = homeworkDescription.split(",");
        for (int index = 0; index < homeworks.length; index ++){
            txtMessage.setText(txtMessage.getText().toString()+(index + 1)+". "+homeworks[index]+"\n");
        }

    }


    /**
     * Return date in specified format.
     * @param milliSeconds Date in milliseconds
     * @return String representing date in specified format
     */
    public String getDate(String milliSeconds){
        try {
            Timestamp ts = Timestamp.valueOf(syncDateparser(milliSeconds));
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd hh:mm");
            Date fechaNueva = format.parse(ts.toString());
            format = new SimpleDateFormat("dd MMM yyyy");
            return format.format(fechaNueva);
        } catch (ParseException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return "";
    }

    public String syncDateparser(String lastSyncDate) {
        long currentDateTime = Long.parseLong(lastSyncDate);
        Date currentDate = new Date(currentDateTime);

        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        String str = dateFormat.format(currentDate);

        return str;
    }




}
