package com.mobiowin.windchim.services;

import android.content.Context;

import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.FirebaseInstanceIdService;
import com.mobiowin.windchim.payload.request.RequestSyncNotification;
import com.mobiowin.windchim.payload.response.ResponseSyncNotification;
import com.mobiowin.windchim.utils.NetworkUtil;
import com.mobiowin.windchim.utils.Social;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class FCMTokenGeneratorService extends FirebaseInstanceIdService {

    private static final String TAG = FCMTokenGeneratorService.class.getName();

    @Override
    public void onTokenRefresh() {
        super.onTokenRefresh();

        String token = FirebaseInstanceId.getInstance().getToken();
        try {
            Device.newInstance(this);
            Device.setNotificationId(token,this);

            sendNotificationToServer(this,"","");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Function used to send notification id to server
     */
    public static void sendNotificationToServer(Context context,String latitude,String longitude) {

        Device.newInstance(context);
        Device device = Device.getInstance();

        Retrofit mRetrofit = NetworkUtil.getRetrofit();
        WindchimesServices windchimesServices = mRetrofit.create(WindchimesServices.class);

        RequestSyncNotification requestSyncNotification = RequestSyncNotification.get(Social.EVENT_SYNC_ACTION,
                Social.ENTITY_APP,Social.NOTIFICATION,device.getModel(),
                device.getNotificationId(context),device.getOSVersion(),device.getDeviceId(context),
                latitude,longitude);

        Call<ResponseSyncNotification> requestSyncNotificationCall = windchimesServices.syncNotificationId(requestSyncNotification);
        requestSyncNotificationCall.enqueue(new Callback<ResponseSyncNotification>() {
            @Override
            public void onResponse(Call<ResponseSyncNotification> call, Response<ResponseSyncNotification> response) {
            }

            @Override
            public void onFailure(Call<ResponseSyncNotification> call, Throwable t) {
            }
        });
    }

}
