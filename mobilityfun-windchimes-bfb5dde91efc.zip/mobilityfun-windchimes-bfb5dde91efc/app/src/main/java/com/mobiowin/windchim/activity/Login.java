package com.mobiowin.windchim.activity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.EditorInfo;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

import com.mobiowin.windchim.R;
import com.mobiowin.windchim.customui.AutoCompleteTextViewOpenSansRegular;
import com.mobiowin.windchim.customui.ButtonOpenSansSemiBold;
import com.mobiowin.windchim.customui.EditTextOpenSansRegular;
import com.mobiowin.windchim.db.Attributes;
import com.mobiowin.windchim.db.DBAdapter;
import com.mobiowin.windchim.payload.request.LoginRequest;
import com.mobiowin.windchim.payload.request.LoginRequestData;
import com.mobiowin.windchim.payload.request.StudentSyncNotification;
import com.mobiowin.windchim.payload.request.StudentSyncNotificationData;
import com.mobiowin.windchim.payload.response.LoginResponse;
import com.mobiowin.windchim.payload.response.LoginResponseDataStudentprofile;
import com.mobiowin.windchim.services.Device;
import com.mobiowin.windchim.services.WindchimesServices;
import com.mobiowin.windchim.utils.CommanUtils;
import com.mobiowin.windchim.utils.NetworkUtil;
import com.mobiowin.windchim.utils.PreferenceUtils;
import com.mobiowin.windchim.utils.Social;

import java.util.ArrayList;
import java.util.HashMap;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class Login extends AppCompatActivity {

    private static final String TAG = Login.class.getCanonicalName();

    private AutoCompleteTextViewOpenSansRegular edtEnrollmentNo;
    private EditTextOpenSansRegular mPasswordView;
    private ButtonOpenSansSemiBold btnSignIn;
    private Spinner spinnerBranches;
    private String deviceID = "", enrollmentNo = "", password = "";
    private PreferenceUtils pref;
    private DBAdapter dbAdapter;
    private HashMap<String,String> branchInfo;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        initializations();
        getAllBranches();
        clickEventFire();
        //merge comment
    }

    /**
     * Function to get all branches from local db
     */
    private void getAllBranches() {

        dbAdapter.open();

        //get all branches events
        Cursor branchCursor = dbAdapter.getAllBranches("F");

        if(branchCursor != null)
            branchCursor.moveToFirst();
        if(branchCursor.moveToFirst()){
            do{
                branchInfo.put(branchCursor.getString(branchCursor.getColumnIndex(Attributes.Database.BRANCH_ADDRESS)),
                               branchCursor.getString(branchCursor.getColumnIndex(Attributes.Database.BRANCH_ID)));
            }while (branchCursor.moveToNext());
        }

        dbAdapter.close();

        ArrayList<String> branches = new ArrayList<>();
        branches.add("Select branch");
        branches.addAll(branchInfo.keySet());

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1,
                new ArrayList<String>(branches));
        spinnerBranches.setAdapter(adapter);

    }


    /**
     * components initializing here
     */
    private void initializations() {
        dbAdapter = new DBAdapter(this);
        pref = new PreferenceUtils(this);
        branchInfo = new HashMap<>();
        edtEnrollmentNo = (AutoCompleteTextViewOpenSansRegular) findViewById(R.id.edtEnrollmentNo);
        mPasswordView = (EditTextOpenSansRegular) findViewById(R.id.password);
        spinnerBranches = (Spinner)findViewById(R.id.spinnerBranch);

        mPasswordView.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView textView, int id, KeyEvent keyEvent) {
                if (id == R.id.login || id == EditorInfo.IME_NULL) {
                    return true;
                }
                return false;
            }
        });

        btnSignIn = (ButtonOpenSansSemiBold) findViewById(R.id.btnSignIn);
    }

    /**
     * clicking action event fire here
     */
    private void clickEventFire() {
        btnSignIn.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
            enrollmentNo = edtEnrollmentNo.getText().toString();
            password = mPasswordView.getText().toString();
            if (isValidData()) {
                if (enrollmentNo.equalsIgnoreCase(getString(R.string.user))
                        && password.equalsIgnoreCase(getString(R.string.password)))
                    launchSurveyPage();
                 else
                    verifyUserWithServer();
            }

            }
//            }
        });
    }

    /**
     * Function used to launch survey page
     */
    private void launchSurveyPage() {
        Intent intent = new Intent(Login.this, ActivityFillSurvey.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
        finish();
    }

    /**
     * Function to validate data
     * @return
     */
    private boolean isValidData() {
        TextView textView = (TextView)spinnerBranches.getChildAt(0);
        if(TextUtils.isEmpty(enrollmentNo)){
            edtEnrollmentNo.setError(getString(R.string.error_field_required));
            return false;
        }else if (TextUtils.isEmpty(password)) {
            mPasswordView.setError(getString(R.string.error_empty_password));
            return false;
        }else if (textView.getText().toString().equalsIgnoreCase("Select branch") ) {
            CommanUtils.showToast(Login.this,"Please select branch");
            return false;
        }
        return true;
    }


    /**
     * Function to verify user with server
     */
    public void verifyUserWithServer() {

        TextView textView = (TextView)spinnerBranches.getChildAt(0);
        String branchId = branchInfo.get(textView.getText().toString());

        CommanUtils.showDialog(Login.this);

        if(NetworkUtil.isInternetConnected(Login.this)) {
            Device.newInstance(this);
            Device device = Device.getInstance();

            LoginRequest loginRequest = new LoginRequest();
            loginRequest.setType(Social.LOGIN_TYPE);
            loginRequest.setAction(Social.SUBMIT_ACTION);
            loginRequest.setEntity(Social.ENTITY_STUDENT);

            LoginRequestData loginRequestData = new LoginRequestData();
            loginRequestData.setBranchid(branchId);
            loginRequestData.setDeviceid(device.getDeviceId(this));
            loginRequestData.setImeino("");
            loginRequestData.setUserid(enrollmentNo);
            loginRequestData.setPassword(password);

            loginRequest.setData(loginRequestData);

            Retrofit mRetrofit = NetworkUtil.getRetrofit();
            WindchimesServices windchimesServices = mRetrofit.create(WindchimesServices.class);

            Call<LoginResponse> loginRequestAPI = windchimesServices.login(loginRequest);
            loginRequestAPI.enqueue(new Callback<LoginResponse>() {
                @Override
                public void onResponse(Call<LoginResponse> call, Response<LoginResponse> response) {
                    if (response.body().getStatus().equalsIgnoreCase("success")){
                        Log.d(TAG, "onResponse: login success");

                        if (response.body().getData()[0].getStudentprofile().length > 0 ){
                            LoginResponseDataStudentprofile studentProfile = response.body().getData()[0].getStudentprofile()[0];
                            saveUserProfile(studentProfile);
                            Log.d(TAG, "onResponse: login success db close");

                            //sync notification for student
                            syncStudentNotification(studentProfile.getBranchId(),studentProfile.getClassName(),
                                    studentProfile.getEnrollmentId());
                        }

                    }else
                        CommanUtils.showToast(Login.this,response.body().getData()[0].getErrmsg()
                        );

                }

                @Override
                public void onFailure(Call<LoginResponse> call, Throwable t) {
                    Log.d(TAG, "onResponse: login fail"+t.getMessage());
                    t.printStackTrace();
                    CommanUtils.showToast(Login.this,getString(R.string.loggedin_error));
                }
            });


        }else{
            CommanUtils.showAlert(Login.this,getString(R.string.connection_error),
                    getResources().getString(R.string.network_connectivity));
        }
    }

    /**
     * Function used to save user profile
     * @param studentProfile : student profile from server
     */
    private void saveUserProfile(LoginResponseDataStudentprofile studentProfile) {
        DBAdapter dbAdapter = new DBAdapter(Login.this);
        dbAdapter.open();

        pref.setUserName(studentProfile.getName());

        dbAdapter.saveProfile(studentProfile.getName(),studentProfile.getBranchId(),studentProfile.getClassName(),
                studentProfile.getDob(),studentProfile.getDoj(),studentProfile.getEnrollmentId(),
                studentProfile.getFatherName(),studentProfile.getFatherNo(),studentProfile.getIsDayBoarding(),
                studentProfile.getIsVan(),studentProfile.getMotherName(),studentProfile.getMotherNo(),
                studentProfile.getPermanentAddress(), (String) studentProfile.getTempAddress());
        dbAdapter.close();

    }

    /**
     * Function used to sync notification for student
     * @param branchId : branch id
     * @param classname : class of student
     * @param enrollmentId
     */
    private void syncStudentNotification(final String branchId, String classname, final String enrollmentId) {
        Log.d(TAG, "onResponse: login success sync noti");
        Device.newInstance(this);
        Device device = Device.getInstance();

        StudentSyncNotification studentSyncNotification = new StudentSyncNotification();
        studentSyncNotification.setType(Social.NOTIFICATION);
        studentSyncNotification.setAction(Social.ACTION_SYNC_TYPE);
        studentSyncNotification.setEntity(Social.ENTITY_STUDENT);

        StudentSyncNotificationData studentSyncNotificationData = new StudentSyncNotificationData();
        studentSyncNotificationData.setUserid(enrollmentNo);
        studentSyncNotificationData.setBranchid(branchId);
        studentSyncNotificationData.setClassname(classname);
        studentSyncNotificationData.setDeviceid(device.getDeviceId(this));
        studentSyncNotificationData.setImeino("");
        studentSyncNotificationData.setNotificationid(device.getNotificationId(this));

        studentSyncNotification.setData(studentSyncNotificationData);

        Retrofit mRetrofit = NetworkUtil.getRetrofit();
        WindchimesServices windchimesServices = mRetrofit.create(WindchimesServices.class);

        Call<LoginResponse> syncStudentNotificationAPI = windchimesServices.syncStudentNotification(studentSyncNotification);
        syncStudentNotificationAPI.enqueue(new Callback<LoginResponse>() {
            @Override
            public void onResponse(Call<LoginResponse> call, Response<LoginResponse> response) {
                Log.d(TAG, "onResponse: login success sync noti res "+response);
                //// TODO: 22/3/17 remove and uncomment
                CommanUtils.hideDialog();
                launchDashboard(enrollmentId,branchId);
//                if (response.body().getStatus().equalsIgnoreCase("success")) {
//                    CommanUtils.showToast(Login.this,getString(R.string.loggedin_success));
//                    launchDashboard(enrollmentId,branchId);
//                }else
//                    CommanUtils.showToast(Login.this,getString(R.string.loggedin_error));

            }

            @Override
            public void onFailure(Call<LoginResponse> call, Throwable t) {
                Log.d(TAG, "onResponse: login success sync not error");
                CommanUtils.showToast(Login.this,getString(R.string.loggedin_error));
            }
        });

    }

    private void launchDashboard(String enrollmentId, String branchId) {
        pref.setLoggedInStatus(true);
        Intent intent = new Intent(Login.this,ActivityFragmentPlatform.class);
        intent.putExtra(Attributes.Database.enrollmentId,enrollmentId);
        intent.putExtra(Attributes.Database.BRANCH_ID,branchId);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
        finish();
    }

    @Override
    public void onBackPressed() {
        Intent intent = new Intent(Login.this, ActivityFragmentPlatform.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
        finish();
    }
}




