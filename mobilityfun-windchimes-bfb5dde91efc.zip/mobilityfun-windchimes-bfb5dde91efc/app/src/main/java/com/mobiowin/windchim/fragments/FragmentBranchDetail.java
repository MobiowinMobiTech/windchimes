package com.mobiowin.windchim.fragments;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.mobiowin.windchim.R;
import com.mobiowin.windchim.activity.ActivityFragmentPlatform;
import com.mobiowin.windchim.customui.TextViewOpenSansRegular;
import com.mobiowin.windchim.db.Attributes;
import com.mobiowin.windchim.db.DBAdapter;


public class FragmentBranchDetail extends Fragment {

    TextViewOpenSansRegular txtAddress, txtMobile, txtEmail;
    String branchId;
    DBAdapter dbAdapter;
    ImageView imgShowMap;
    Intent intent;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        branchId = getArguments().getString("branchId");
        dbAdapter = new DBAdapter(getActivity());

    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View branchDetailView = inflater.inflate(R.layout.fragment_branch_details, null);


        intent = new Intent(Intent.ACTION_CALL);

        txtAddress = (TextViewOpenSansRegular) branchDetailView.findViewById(R.id.txtAddress);
        txtMobile = (TextViewOpenSansRegular) branchDetailView.findViewById(R.id.txtMobileNo);


        //when user click on call button
        txtMobile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (android.os.Build.VERSION.SDK_INT > android.os.Build.VERSION_CODES.LOLLIPOP){
                    if (ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                        ActivityCompat.requestPermissions(getActivity(),new String[]{Manifest.permission.CALL_PHONE},0);
                        return;
                    }else
                        callToBranch();
                } else{
                   callToBranch();
                }
            }
        });
        txtEmail = (TextViewOpenSansRegular)branchDetailView.findViewById(R.id.txtEmail);
        imgShowMap = (ImageView)branchDetailView.findViewById(R.id.imgViewLocation);

        //to open map
        imgShowMap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Uri gmmIntentUri = Uri.parse("geo:0,0?q="+txtAddress.getText().toString());
                Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
                mapIntent.setPackage("com.google.android.apps.maps");
                startActivity(mapIntent);
            }
        });

        return branchDetailView;
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == 0)
            if (grantResults.length > 0
                    && grantResults[0] == PackageManager.PERMISSION_GRANTED)
                callToBranch();
    }

    private void callToBranch() {
        intent.setData(Uri.parse("tel:" + txtMobile.getText().toString()));
        getActivity().startActivity(intent);
    }

    @Override
    public void onResume() {
        super.onResume();
        ActivityFragmentPlatform.changeToolbarTitleIcon(getResources().getString(R.string.branch_details),
                R.drawable.ic_arrow_back_black_24dp);
        getBranchDetail();
    }

    /**
     * Function to get branch detailps from local db
     */
    private void getBranchDetail() {
        dbAdapter.open();
        Cursor cursor = dbAdapter.getBranchById(branchId);

        if (cursor != null) {
            cursor.moveToFirst();
            if (cursor.moveToFirst()) {
                do {
                    txtAddress.setText(cursor.getString(cursor.getColumnIndex(Attributes.Database.BRANCH_ADDRESS)));
                    txtEmail.setText(cursor.getString(cursor.getColumnIndex(Attributes.Database.EMAIL_ID)));
                    txtMobile.setText(cursor.getString(cursor.getColumnIndex(Attributes.Database.MOBILE_NO)));
                } while (cursor.moveToNext());
            }
        }
        dbAdapter.close();

    }

}
