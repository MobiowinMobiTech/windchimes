package com.mobiowin.windchim.adapter;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.FragmentManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;

import com.mobiowin.windchim.R;
import com.mobiowin.windchim.fragments.ZoomImage;
import com.mobiowin.windchim.utils.CommanUtils;
import com.mobiowin.windchim.utils.Config;

import java.util.ArrayList;


public class GridAdapter extends ArrayAdapter<String> {
    ArrayList<String> eventImages;
    Context context;
    FragmentManager fragmentManager;

    boolean isFullscreen = false;

    public GridAdapter(Context activity, int resource, ArrayList<String> eventImages, FragmentManager supportFragmentManager) {
        super(activity,resource);
        this.eventImages = eventImages;
        this.context = activity;
        this.fragmentManager = supportFragmentManager;
    }

    @Override
    public int getCount() {
        return eventImages.size();
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        GridAdapter.ViewHolder viewHolder = new GridAdapter.ViewHolder();
        if(convertView==null){
            LayoutInflater layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = layoutInflater.inflate(R.layout.custom_event_image,null);
            viewHolder.eventImage = (ImageView) convertView.findViewById(R.id.imageEvent);

            convertView.setTag(viewHolder);
        }else{
            viewHolder = (GridAdapter.ViewHolder) convertView.getTag();
        }

        CommanUtils.updateImage(context,viewHolder.eventImage,eventImages.get(position),R.drawable.logo);

        viewHolder.eventImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ZoomImage zoomImage = new ZoomImage();
                Bundle bundle = new Bundle();
                zoomImage.setArguments(bundle);
                bundle.putString(Config.IMAGE_URL,eventImages.get(position));

                fragmentManager.beginTransaction()
                        .replace(R.id.platform, zoomImage)
                        .addToBackStack(null).commit();


            }
        });

        return convertView;
    }


    class ViewHolder {
        ImageView eventImage;

    }











}
