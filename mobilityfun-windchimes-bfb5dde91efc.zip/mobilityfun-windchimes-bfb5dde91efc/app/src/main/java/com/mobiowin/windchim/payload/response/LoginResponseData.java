package com.mobiowin.windchim.payload.response;

public class LoginResponseData {

    String errmsg;

    public String getErrmsg() {
        return errmsg;
    }

    public void setErrmsg(String errmsg) {
        this.errmsg = errmsg;
    }

    private LoginResponseDataStudentprofile[] studentprofile;

    public LoginResponseDataStudentprofile[] getStudentprofile() {
        return this.studentprofile;
    }

    public void setStudentprofile(LoginResponseDataStudentprofile[] studentprofile) {
        this.studentprofile = studentprofile;
    }
}
