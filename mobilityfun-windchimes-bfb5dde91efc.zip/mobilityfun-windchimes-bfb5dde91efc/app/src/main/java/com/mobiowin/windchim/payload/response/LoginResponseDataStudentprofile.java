package com.mobiowin.windchim.payload.response;

public class LoginResponseDataStudentprofile {
    private String enrollmentId;
    private String branchId;
    private String fatherName;
    private String isVan;
    private String motherName;
    private String className;
    private String motherNo;
    private long createDt;
    private String deleteFlag;
    private Object tempAddress;
    private String fatherNo;
    private String createdBy;
    private long dob;
    private String name;
    private String modifiedBy;
    private long modifyDt;
    private String id;
    private String permanentAddress;
    private String isDayBoarding;
    private long doj;

    public String getEnrollmentId() {
        return this.enrollmentId;
    }

    public void setEnrollmentId(String enrollmentId) {
        this.enrollmentId = enrollmentId;
    }

    public String getBranchId() {
        return this.branchId;
    }

    public void setBranchId(String branchId) {
        this.branchId = branchId;
    }

    public String getFatherName() {
        return this.fatherName;
    }

    public void setFatherName(String fatherName) {
        this.fatherName = fatherName;
    }

    public String getIsVan() {
        return this.isVan;
    }

    public void setIsVan(String isVan) {
        this.isVan = isVan;
    }

    public String getMotherName() {
        return this.motherName;
    }

    public void setMotherName(String motherName) {
        this.motherName = motherName;
    }

    public String getClassName() {
        return this.className;
    }

    public void setClassName(String className) {
        this.className = className;
    }

    public String getMotherNo() {
        return this.motherNo;
    }

    public void setMotherNo(String motherNo) {
        this.motherNo = motherNo;
    }

    public long getCreateDt() {
        return this.createDt;
    }

    public void setCreateDt(long createDt) {
        this.createDt = createDt;
    }

    public String getDeleteFlag() {
        return this.deleteFlag;
    }

    public void setDeleteFlag(String deleteFlag) {
        this.deleteFlag = deleteFlag;
    }

    public Object getTempAddress() {
        return this.tempAddress;
    }

    public void setTempAddress(Object tempAddress) {
        this.tempAddress = tempAddress;
    }

    public String getFatherNo() {
        return this.fatherNo;
    }

    public void setFatherNo(String fatherNo) {
        this.fatherNo = fatherNo;
    }

    public String getCreatedBy() {
        return this.createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public long getDob() {
        return this.dob;
    }

    public void setDob(long dob) {
        this.dob = dob;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getModifiedBy() {
        return this.modifiedBy;
    }

    public void setModifiedBy(String modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    public long getModifyDt() {
        return this.modifyDt;
    }

    public void setModifyDt(long modifyDt) {
        this.modifyDt = modifyDt;
    }

    public String getId() {
        return this.id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPermanentAddress() {
        return this.permanentAddress;
    }

    public void setPermanentAddress(String permanentAddress) {
        this.permanentAddress = permanentAddress;
    }

    public String getIsDayBoarding() {
        return this.isDayBoarding;
    }

    public void setIsDayBoarding(String isDayBoarding) {
        this.isDayBoarding = isDayBoarding;
    }

    public long getDoj() {
        return this.doj;
    }

    public void setDoj(long doj) {
        this.doj = doj;
    }
}
