package com.mobiowin.windchim.activity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;

import com.google.firebase.messaging.FirebaseMessaging;
import com.mobiowin.windchim.R;
import com.mobiowin.windchim.db.DBAdapter;
import com.mobiowin.windchim.payload.request.RequestInitialData;
import com.mobiowin.windchim.payload.response.ResponseInitialData;
import com.mobiowin.windchim.services.WindchimesServices;
import com.mobiowin.windchim.utils.CommanUtils;
import com.mobiowin.windchim.utils.Config;
import com.mobiowin.windchim.utils.NetworkUtil;
import com.mobiowin.windchim.utils.PreferenceUtils;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class Splashscreen extends AppCompatActivity {

    private DBAdapter dbAdapter;
    private PreferenceUtils pref;
    String TAG = Splashscreen.class.getSimpleName();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        dbAdapter = new DBAdapter(this);
        pref = new PreferenceUtils(this);

        dbAdapter.open();
        if(dbAdapter.getMasterTableCount()<1){
            dbAdapter.insertTimeSpan("0","0");
        }
        dbAdapter.close();

        getRetrofitCallBannerSlider();

    }

    /**
     * Function to get initial data from server
     */
    public void getRetrofitCallBannerSlider() {
        if (NetworkUtil.isInternetConnected(Splashscreen.this)) {
            dbAdapter.open();

            RequestInitialData slidingBanner = RequestInitialData.get("", "", dbAdapter.getlastSyncdate(Config.APP_INIT_TIMESPAN));
            dbAdapter.close();
            Retrofit mRetrofit = NetworkUtil.getRetrofit();
            WindchimesServices windchimesServices = mRetrofit.create(WindchimesServices.class);
            final Call<ResponseInitialData> appSyncBanner = windchimesServices.appSyncBanner(slidingBanner);

            appSyncBanner.enqueue(new Callback<ResponseInitialData>() {
                @Override
                public void onResponse(Call<ResponseInitialData> call, Response<ResponseInitialData> response) {
                    if(response.body()!=null) {
                        dbAdapter.open();

                        // add banners
                        addBannersInSharedPref(response.body().getData()[0].getBannerlist());

                        addBranchesInLocalDatabase(response.body().getData()[0].getBranchlist());

                        registerTopics(response.body().getData()[0].getBroadcasttopiclist());

                        dbAdapter.updateAppInitSpan(response.body().getData()[0].getLastsyncdate());

                        dbAdapter.close();
                        launchDashboard();
                    }else{
                        showExitAlert(getString(R.string.technical_issue));
                    }
                }

                @Override
                public void onFailure(Call<ResponseInitialData> call, Throwable t) {
                    t.printStackTrace();

                    if (CommanUtils.isNewUser(Splashscreen.this)){
                        showExitAlert(getString(R.string.technical_issue));
                    }else
                        launchDashboard();
                }
            });
        }else {
            if (CommanUtils.isNewUser(Splashscreen.this)){
                showExitAlert(getString(R.string.first_time_user_without_network));
            }else{
                launchDashboard();
            }
        }
    }

    /**
     * Function used to dynamically add topics in FCM
     * @param broadcasttopiclist
     */
    private void registerTopics(ResponseInitialData.Broadcasttopiclist[] broadcasttopiclist) {
        // register to topics
        for (int index = 0; index < broadcasttopiclist.length; index ++)
            FirebaseMessaging.getInstance().subscribeToTopic(broadcasttopiclist[index].getBroadcastTopic().replace("/topics/",""));

    }

    /**
     * Function used to add branches in Local database
     * @param branchlist
     */
    private void addBranchesInLocalDatabase(ResponseInitialData.Branchlist[] branchlist) {
        for (int index = 0 ; index < branchlist.length ; index++){
            ResponseInitialData.Branchlist branch = branchlist[index];
            dbAdapter.insertBranches(branch.getBranchId(),null,branch.getAddress(),branch.getLatitude()
                    ,branch.getLongitude(),branch.getBranchType(),branch.getEmailId(),branch.getMobileNo(),branch.getCreatedBy(),
                    branch.getDeleteFlag(),branch.getCreateDt(),branch.getModifiedBy(),branch.getModifyDt());
        }

    }

    /**
     * Function used to add banners in SP
     * @param bannerlist
     */
    private void addBannersInSharedPref(ResponseInitialData.Bannerlist[] bannerlist) {
        if(bannerlist.length>0) {
            pref.setBanners(bannerlist);
        }
    }

    /**
     * Function used to exit app
     * @param message
     */
    private void showExitAlert(String message) {
        AlertDialog.Builder alert = new AlertDialog.Builder(this);
        alert.setTitle(getString(R.string.connection_error));
        alert.setMessage(message);
        alert.setCancelable(false);
        alert.setPositiveButton("Exit", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                finish();
            }
        });
        alert.show();
    }


    private void launchDashboard() {
        Intent intent = new Intent(Splashscreen.this, ActivityFragmentPlatform.class);
        try {
            Bundle bundle = getIntent().getExtras();
            for (String key: getIntent().getExtras().keySet()){
                intent.putExtra(Config.TITLE,bundle.getString(Config.TITLE));
                intent.putExtra(Config.NOTIFICATION_TYPE,bundle.getString(Config.NOTIFICATION_TYPE));
                intent.putExtra(Config.BODY,bundle.getString(Config.BODY));
                intent.putExtra(Config.TITLE,bundle.getString(Config.TITLE));
                intent.putExtra(Config.EVENT_ID,bundle.getString(Config.EVENT_ID));
                intent.putExtra(Config.NOTIFICATION_COUNT,bundle.getInt(Config.NOTIFICATION_COUNT));
            }
        }catch (Exception ex){

        }

        startActivity(intent);
        finish();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        CommanUtils.hideDialog();
    }

    @Override
    protected void onPause() {
        super.onPause();
        CommanUtils.hideDialog();
    }
}
