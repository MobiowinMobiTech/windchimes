package com.mobiowin.windchim.fragments;

import android.database.Cursor;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;

import com.mobiowin.windchim.R;
import com.mobiowin.windchim.activity.ActivityFragmentPlatform;
import com.mobiowin.windchim.adapter.ListsAdapter;
import com.mobiowin.windchim.customui.TextViewOpenSansRegular;
import com.mobiowin.windchim.db.Attributes;
import com.mobiowin.windchim.db.DBAdapter;
import com.mobiowin.windchim.utils.Config;

public class FragmentHomework extends Fragment {
    String enrollmentId, branchId;
    ListView homeworkList;
    TextViewOpenSansRegular txtNoData;
    private String[]  listOfHomeworkIds, listOfHomeworkDescription, listHomeworkDate;
    int counter = 0;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        enrollmentId = getArguments().getString(Attributes.Database.enrollmentId);
        branchId = getArguments().getString(Attributes.Database.BRANCH_ID);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_list_view,null);

        homeworkList = (ListView) view.findViewById(R.id.listView);
        txtNoData = (TextViewOpenSansRegular) view.findViewById(R.id.txtDataNotFound);


        homeworkList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                FragmentHomeworkDetails fragmentHomeworkDetails = new FragmentHomeworkDetails();
                Bundle bundle = new Bundle();
                bundle.putString(Config.HOMEWORK_DATE,listHomeworkDate[position]);
                bundle.putString(Config.HOMEWORK_DESCRIPTION,listOfHomeworkDescription[position]);
                fragmentHomeworkDetails.setArguments(bundle);
                getActivity().getSupportFragmentManager().beginTransaction().
                        replace(R.id.platform, fragmentHomeworkDetails).addToBackStack(null).commit();
            }
        });

        getHomeworks();



        return view;
    }

    /**
     * Function used to get homework from local db
     */
    private void getHomeworks() {
        DBAdapter dbAdapter = new DBAdapter(getActivity());
        dbAdapter.open();

        Cursor cursor = dbAdapter.getHomeWorkbyEnrollmentId(enrollmentId,branchId);

        listOfHomeworkIds = new String[cursor.getCount()];
        listOfHomeworkDescription = new String[cursor.getCount()];
        listHomeworkDate = new String[cursor.getCount()];
        counter = 0;

        Log.d("", "getHomeworks: "+cursor.getCount());


        if (cursor != null) {
            cursor.moveToFirst();
            if (cursor.moveToFirst()) {
                do {
                    listOfHomeworkIds[counter] = (cursor.getString(cursor.getColumnIndex(Attributes.Database.homeworkId)));
                    listOfHomeworkDescription[counter] = (cursor.getString(cursor.getColumnIndex(Attributes.Database.homework)));
                    listHomeworkDate[counter] = (cursor.getString(cursor.getColumnIndex(Attributes.Database.homework_date)));;
                    counter = counter + 1;
                } while (cursor.moveToNext());
            }
        }


        Log.d("", "getHomeworks: "+listOfHomeworkIds.length);
        Log.d("", "getHomeworks: "+listOfHomeworkDescription.length);
        Log.d("", "getHomeworks: "+listHomeworkDate.length);

        if (listOfHomeworkIds.length > 0) {
            String[] subtitle = new String[listOfHomeworkIds.length];
            for (int index = 0 ; index < listOfHomeworkIds.length ; index ++)
                subtitle[index] = "";

            homeworkList.setAdapter(new ListsAdapter(getActivity(), 0, listOfHomeworkDescription,subtitle , listHomeworkDate));
        }else {
            txtNoData.setVisibility(View.VISIBLE);
        }



    }

    @Override
    public void onResume() {
        super.onResume();
        ActivityFragmentPlatform.changeToolbarTitleIcon(getResources().getString(R.string.homework),
                R.drawable.ic_arrow_back_black_24dp);
    }
}
