package com.mobiowin.windchim.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;

import com.mobiowin.windchim.R;
import com.mobiowin.windchim.customui.RoundedImageView;
import com.mobiowin.windchim.customui.TextViewOpenSansRegular;
import com.mobiowin.windchim.customui.TextViewOpenSansSemiBold;
import com.mobiowin.windchim.utils.CommanUtils;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;


public class ListsAdapter extends  ArrayAdapter<String> {

    private final static String TAG = ListsAdapter.class.getCanonicalName();
    private String[] titleItemsList,subTitleItemsList,eventDatesORgroupLogo;
    private Context context;
    private int status = 0;


    public ListsAdapter(Context context, int resource, String[] objects1, String[] objects2, String[] objects3) {
        super(context, resource, objects1);
        status=resource;
        titleItemsList = objects1;
        subTitleItemsList = objects2;
        eventDatesORgroupLogo = objects3;
        this.context = context;
    }


    @Override
    public int getCount() {
        return super.getCount();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder = new ViewHolder();
        if(convertView==null){
            LayoutInflater layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = layoutInflater.inflate(R.layout.fragment_list_row,null);
            viewHolder.txtTitle = (TextViewOpenSansRegular) convertView.findViewById(R.id.txtPrimaryRow);
            viewHolder.txtSubTitle = (TextViewOpenSansRegular) convertView.findViewById(R.id.txtSecondaryRow);
            viewHolder.txtDay = (TextViewOpenSansSemiBold) convertView.findViewById(R.id.txtDayRow);
            viewHolder.txtDate = (TextViewOpenSansRegular) convertView.findViewById(R.id.txtDateRow);
            viewHolder.llDateCircle = (LinearLayout) convertView.findViewById(R.id.rlDateCircle);
            viewHolder.logo = (RoundedImageView) convertView.findViewById(R.id.img_logo);
            convertView.setTag(viewHolder);
        }else{
            viewHolder = (ViewHolder) convertView.getTag();
        }

        try {
            viewHolder.txtTitle.setText("" + titleItemsList[position]);
            viewHolder.txtSubTitle.setText("" + subTitleItemsList[position]);

            if(eventDatesORgroupLogo!=null && status==1){
                viewHolder.llDateCircle.setVisibility(View.GONE);
                viewHolder.logo.setVisibility(View.VISIBLE);
                CommanUtils.updateImage(context,viewHolder.logo,eventDatesORgroupLogo[position],R.drawable.logo);

            }else if(eventDatesORgroupLogo!=null){
                viewHolder.logo.setVisibility(View.GONE);
                viewHolder.llDateCircle.setVisibility(View.VISIBLE);
                try {
                    String date = getDate(eventDatesORgroupLogo[position]);
                    String dateArray[] = date.split(" ");

                    viewHolder.txtDay.setText(dateArray[0]);
                    viewHolder.txtDate.setText(dateArray[1]);

                }catch (Exception e){
                    e.printStackTrace();
                }
            }else{
                viewHolder.logo.setVisibility(View.GONE);
                viewHolder.llDateCircle.setVisibility(View.GONE);
            }
        }catch (NullPointerException e){
            e.printStackTrace();
        }
        return convertView;
    }


    class ViewHolder {

        TextViewOpenSansRegular txtTitle,txtSubTitle,txtDate;
        TextViewOpenSansSemiBold txtDay;
        LinearLayout llDateCircle;
        RoundedImageView logo;
    }

    /**
     * Return date in specified format.
     * @param milliSeconds Date in milliseconds
     * @return String representing date in specified format
     */
    public String getDate(String milliSeconds){
        try {
            Timestamp ts = Timestamp.valueOf(syncDateparser(milliSeconds));
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd hh:mm");
            Date fechaNueva = format.parse(ts.toString());
            format = new SimpleDateFormat("dd MMM yyyy");
            return format.format(fechaNueva);
        } catch (ParseException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return "";
    }

    public String syncDateparser(String lastSyncDate) {
        long currentDateTime = Long.parseLong(lastSyncDate);
        Date currentDate = new Date(currentDateTime);

        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        String str = dateFormat.format(currentDate);

        return str;
    }




}
