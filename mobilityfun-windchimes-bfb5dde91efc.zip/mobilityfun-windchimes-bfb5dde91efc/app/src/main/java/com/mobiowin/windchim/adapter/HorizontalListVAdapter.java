package com.mobiowin.windchim.adapter;

import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.mobiowin.windchim.R;
import com.mobiowin.windchim.fragments.FragmentBranchDetail;
import com.mobiowin.windchim.fragments.FragmentViewDetailsEvent;
import com.mobiowin.windchim.utils.CommanUtils;
import com.mobiowin.windchim.customui.RoundedImageView;
import com.mobiowin.windchim.utils.Config;
import com.mobiowin.windchim.utils.Social;

import java.util.ArrayList;


public class HorizontalListVAdapter extends RecyclerView.Adapter<HorizontalListVAdapter.ViewHolder> {

    private ArrayList<String> titlesItems,idsItems,logosItems;
    private int image;
    private FragmentActivity context;
    private String redirectPosition;

    public HorizontalListVAdapter(FragmentActivity context, ArrayList<String> logosItems, ArrayList<String> titlesItems,
                                  ArrayList<String> idsItems, int image, String redirectPosition) {
        super();
        this.context = context;
        this.titlesItems = titlesItems;
        this.idsItems = idsItems;
        this.logosItems = logosItems;
        this.image=image;
        this.redirectPosition = redirectPosition;
   }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, final int position) {
        View v = LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.grid_item, viewGroup, false);
        ViewHolder viewHolder = new ViewHolder(v);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(ViewHolder viewHolder, final int i) {
        viewHolder.tvSpecies.setText(titlesItems.get(i));

        if(logosItems==null ) {
            viewHolder.imgThumbnail.setImageResource(image);
        }else if(redirectPosition.equals(Social.NAVIGATE_TO_EVENT)){
            CommanUtils.updateImage(context,viewHolder.imgThumbnail,logosItems.get(i),R.drawable.ic_add_alert_black_24dp);
        }else if(redirectPosition.equals(Social.NAVIGATE_TO_PREVIOUS_EVENT)){
            CommanUtils.updateImage(context,viewHolder.imgThumbnail,logosItems.get(i),R.drawable.ic_add_alert_black_24dp);
        }else if(redirectPosition.equals(Social.NAVIGATE_TO_BRANCHES)){
            //// TODO: 5/3/17  change icon
            CommanUtils.updateImage(context,viewHolder.imgThumbnail,logosItems.get(i),R.drawable.logo);
        }

        viewHolder.cardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getNavigate(redirectPosition,i);
            }
        });
    }

    @Override
    public int getItemCount() {
        return titlesItems.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder{

        public RoundedImageView imgThumbnail;
        public TextView tvSpecies;
        public CardView cardView;

        public ViewHolder(View itemView) {
            super(itemView);
            imgThumbnail = (RoundedImageView) itemView.findViewById(R.id.img_thumbnail);
            tvSpecies = (TextView) itemView.findViewById(R.id.tv_species);
            cardView = (CardView) itemView.findViewById(R.id.cardView);
        }

    }

    /**
     * Function used to navigate page based on list item clicked for event and branch
     * @param redirectPage
     * @param pos
     */
    private void getNavigate(String redirectPage,int pos){
        FragmentViewDetailsEvent fragmentViewDetailsEvent;
        Bundle bundle;
        switch (redirectPage){

            case Social.NAVIGATE_TO_EVENT:
                fragmentViewDetailsEvent = new FragmentViewDetailsEvent();
                bundle = new Bundle();
                bundle.putString(Config.ACTION,Config.ACTION_UPCOMMING_EVENT);
                bundle.putString(Config.EVENT_ID,idsItems.get(pos));
                fragmentViewDetailsEvent.setArguments(bundle);

                context.getSupportFragmentManager().beginTransaction().
                        replace(R.id.platform, fragmentViewDetailsEvent).addToBackStack(null).commit();
                break;

            case Social.NAVIGATE_TO_PREVIOUS_EVENT:

                fragmentViewDetailsEvent = new FragmentViewDetailsEvent();
                bundle = new Bundle();
                bundle.putString(Config.ACTION,Config.ACTION_PREVIOUS_EVENT);
                bundle.putString(Config.EVENT_ID,idsItems.get(pos));
                fragmentViewDetailsEvent.setArguments(bundle);

                context.getSupportFragmentManager().beginTransaction().
                        replace(R.id.platform, fragmentViewDetailsEvent).addToBackStack(null).commit();
                break;

            case Social.NAVIGATE_TO_BRANCHES:
                FragmentBranchDetail fragmentBranchDetail = new FragmentBranchDetail();
                bundle = new Bundle();
                bundle.putString("branchId",idsItems.get(pos));
                fragmentBranchDetail.setArguments(bundle);
                context.getSupportFragmentManager().beginTransaction().
                        replace(R.id.platform, fragmentBranchDetail).addToBackStack(null).commit();
                break;

        }
    }
}

