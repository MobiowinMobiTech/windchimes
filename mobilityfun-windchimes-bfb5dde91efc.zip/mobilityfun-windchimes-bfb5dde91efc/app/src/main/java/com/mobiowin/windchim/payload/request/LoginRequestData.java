package com.mobiowin.windchim.payload.request;

public class LoginRequestData {
    private String branchid;
    private String password;
    private String imeino;
    private String userid;
    private String deviceid;

    public String getBranchid() {
        return this.branchid;
    }

    public void setBranchid(String branchid) {
        this.branchid = branchid;
    }

    public String getPassword() {
        return this.password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getImeino() {
        return this.imeino;
    }

    public void setImeino(String imeino) {
        this.imeino = imeino;
    }

    public String getUserid() {
        return this.userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public String getDeviceid() {
        return this.deviceid;
    }

    public void setDeviceid(String deviceid) {
        this.deviceid = deviceid;
    }
}
