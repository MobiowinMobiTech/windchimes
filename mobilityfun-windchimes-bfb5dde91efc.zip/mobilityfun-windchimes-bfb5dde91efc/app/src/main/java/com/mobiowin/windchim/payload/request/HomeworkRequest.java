package com.mobiowin.windchim.payload.request;

public class HomeworkRequest {
    private HomeworkRequestData data;
    private String action;
    private String type;
    private String entity;

    public HomeworkRequestData getData() {
        return this.data;
    }

    public void setData(HomeworkRequestData data) {
        this.data = data;
    }

    public String getAction() {
        return this.action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public String getType() {
        return this.type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getEntity() {
        return this.entity;
    }

    public void setEntity(String entity) {
        this.entity = entity;
    }
}
