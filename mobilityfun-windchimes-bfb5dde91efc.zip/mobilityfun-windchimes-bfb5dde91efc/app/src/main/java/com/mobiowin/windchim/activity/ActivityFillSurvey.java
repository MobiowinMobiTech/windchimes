package com.mobiowin.windchim.activity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.View;

import com.mobiowin.windchim.R;
import com.mobiowin.windchim.customui.AutoCompleteTextViewOpenSansRegular;
import com.mobiowin.windchim.customui.ButtonOpenSansSemiBold;
import com.mobiowin.windchim.payload.request.SubmitFeedback;
import com.mobiowin.windchim.payload.response.SubmitFeedbackResponse;
import com.mobiowin.windchim.services.WindchimesServices;
import com.mobiowin.windchim.utils.CommanUtils;
import com.mobiowin.windchim.utils.NetworkUtil;
import com.mobiowin.windchim.utils.Social;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;


public class ActivityFillSurvey extends AppCompatActivity{

    private AutoCompleteTextViewOpenSansRegular edtEmail, edtName, edtMobile, edtMessage ,
            edtLeadName, edtAddress;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_survey);

        edtEmail = (AutoCompleteTextViewOpenSansRegular)findViewById(R.id.edtEmail);
        edtName = (AutoCompleteTextViewOpenSansRegular)findViewById(R.id.edtName);
        edtMobile = (AutoCompleteTextViewOpenSansRegular)findViewById(R.id.edtMobile);
        edtMessage = (AutoCompleteTextViewOpenSansRegular)findViewById(R.id.edtMessage);
        edtLeadName = (AutoCompleteTextViewOpenSansRegular)findViewById(R.id.edtLeadName);
        edtAddress = (AutoCompleteTextViewOpenSansRegular)findViewById(R.id.edtAddress);

        ButtonOpenSansSemiBold btnSubmit = (ButtonOpenSansSemiBold)findViewById(R.id.btnSubmitFeedback);
        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                submitSurvey();
            }
        });

    }

    /**
     * Function used to save survey
     */
    private void submitSurvey() {
        if (isValidData()){
            submitFeedbackWithServer();
        }
    }

    /**
     * Function to submit feedback data  to server
     */
    private void submitFeedbackWithServer() {
        CommanUtils.showDialog(this);

        SubmitFeedback submitFeedback = new SubmitFeedback();
        submitFeedback.setAction(Social.SUBMIT_ACTION);
        submitFeedback.setType(Social.MARKETING);
        submitFeedback.setEntity(Social.ENTITY_APP);
        SubmitFeedback.Data data = new SubmitFeedback.Data();
        data.setMobileno(edtMobile.getText().toString());
        data.setEmailid(edtEmail.getText().toString());
        data.setName(edtName.getText().toString());
        data.setMessage(edtMessage.getText().toString());
        data.setLeadname(edtLeadName.getText().toString());
        data.setAddress(edtAddress.getText().toString());
        submitFeedback.setData(data);

        // server call for submit feedback

        Retrofit mRetrofit = NetworkUtil.getRetrofit();
        WindchimesServices windchimesServices = mRetrofit.create(WindchimesServices.class);

        Call<SubmitFeedbackResponse> resRegistrationCall = windchimesServices.submitFeedback(submitFeedback);
        resRegistrationCall.enqueue(new Callback<SubmitFeedbackResponse>() {
            @Override
            public void onResponse(Call<SubmitFeedbackResponse> call, Response<SubmitFeedbackResponse> response) {
                CommanUtils.hideDialog();
                if (response.body().getStatus().equalsIgnoreCase("success")){
                    showOptionalAlert(true);
                }else {
                    CommanUtils.showAlert(ActivityFillSurvey.this,getString(R.string.survey_title),
                            getString(R.string.technical_issue));
                }
            }

            @Override
            public void onFailure(Call<SubmitFeedbackResponse> call, Throwable t) {
                CommanUtils.hideDialog();
                CommanUtils.showAlert(ActivityFillSurvey.this,getString(R.string.survey_title),
                        getString(R.string.technical_issue));
            }
        });

    }

    /**
     * Function to display optional alert
     * 1. Open dashboard
     * 2. Add another survey
     * @param isSurveyCompleted
     */
    private void showOptionalAlert(boolean isSurveyCompleted) {
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(this);
        alertDialog.setMessage(getString(R.string.survey_submit_success));
        alertDialog.setTitle(getString(R.string.app_name));

        alertDialog.setPositiveButton("Open Dashboard", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                Intent intent = new Intent(ActivityFillSurvey.this, ActivityFragmentPlatform.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                finish();
            }
        });
        if (isSurveyCompleted)
            alertDialog.setNegativeButton("Add another survey", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    clearSurveyForm();
                }
            });


        alertDialog.setNeutralButton("Exit", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                finish();
            }
        });

        alertDialog.show();
    }

    /**
     * Function used to clear survey form
     */
    private void clearSurveyForm() {
        edtAddress.setText("");
        edtEmail.setText("");
        edtLeadName.setText("");
        edtMessage.setText("");
        edtMobile.setText("");
        edtName.setText("");
    }


    /**
     * Function to validate data
     * @return : validation result
     */
    private boolean isValidData() {
        String email = edtEmail.getText().toString();
        String name = edtName.getText().toString();
        String mobile = edtMobile.getText().toString();
        String message = edtMessage.getText().toString();
        String leadName = edtLeadName.getText().toString();
        String address = edtAddress.getText().toString();

        if (TextUtils.isEmpty(name)){
            CommanUtils.showAlert(this,getString(R.string.survey_title),getString(R.string.error_empty_name));
            return false;
        }else if (TextUtils.isEmpty(mobile) || mobile.length() < 10) {
            CommanUtils.showAlert(this,getString(R.string.survey_title),getString(R.string.mobile_validation_mesasage));
            return false;
        }else if (TextUtils.isEmpty(email) || !CommanUtils.isEmailValid(email)){
            CommanUtils.showAlert(this,getString(R.string.survey_title),getString(R.string.email_validation_mesasage));
            return false;
        }else if (TextUtils.isEmpty(message)){
            CommanUtils.showAlert(this,getString(R.string.survey_title),getString(R.string.feedback_message_validation_message));
            return false;
        }else if (TextUtils.isEmpty(leadName)){
            CommanUtils.showAlert(this,getString(R.string.survey_title),getString(R.string.survey_leadname_validation_message));
            return false;
        }else if (TextUtils.isEmpty(address)){
            CommanUtils.showAlert(this,getString(R.string.survey_title),getString(R.string.survey_address_validation_message));
            return false;
        }
        return true;
    }


    @Override
    public void onBackPressed() {
        showOptionalAlert(false);
    }
}
