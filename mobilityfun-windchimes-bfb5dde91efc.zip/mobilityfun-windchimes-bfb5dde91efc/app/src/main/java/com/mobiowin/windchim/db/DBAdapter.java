package com.mobiowin.windchim.db;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.mobiowin.windchim.utils.Config;

public class DBAdapter {

	final String TAG = DBAdapter.class.getCanonicalName();
	private DBHelper sqLiteHelper;
	private SQLiteDatabase sqLiteDatabase;
	private Context context;


	public DBAdapter(Context c) {
		context=c;

	}

	public DBAdapter open(){
		sqLiteHelper = new DBHelper(context, Attributes.Database.DB_NAME, null,1);
		sqLiteDatabase = sqLiteHelper.getWritableDatabase();
		return this;
	}

	public void close(){
		if(sqLiteDatabase!=null && sqLiteDatabase.isOpen())
			sqLiteDatabase.close();
		if(sqLiteHelper!=null)
			sqLiteHelper.close();
	}


	//	Database methods for event insertion,updation,deletion,selection operations
	public int insertUpcommingEventInDB(String event_id, String event_title, String event_sub_title, String event_desc,
                                        String event_startdate, String event_enddate, String event_is_Deleted, String event_category,
                                        String location, String img1, String img2, String img3, String img4) {

		int status = 0;
		ContentValues cv = new ContentValues();
		try {
			cv.put(Attributes.Database.EVENT_TITLE, (event_title != null ? event_title : "NA"));
			cv.put(Attributes.Database.EVENT_SUB_TITLE, (event_sub_title != null ? event_sub_title : "NA"));
			cv.put(Attributes.Database.EVENT_DESCRIPTION, (event_desc != null ? event_desc : "NA"));
			cv.put(Attributes.Database.EVENT_START_DATE, (event_startdate != null ? event_startdate : "NA"));
			cv.put(Attributes.Database.EVENT_END_DATE, (event_enddate != null ? event_enddate : "NA"));
			cv.put(Attributes.Database.EVENT_CATEGORY, (event_category != null ? event_category : "NA"));
			cv.put(Attributes.Database.EVENT_LOCATION, (location != null ? location : "NA"));
			cv.put(Attributes.Database.EVENT_IS_DELETED, event_is_Deleted);
			cv.put(Attributes.Database.EVENT_IMG1,img1);
			cv.put(Attributes.Database.EVENT_IMG2,img2);
			cv.put(Attributes.Database.EVENT_IMG3,img3);
			cv.put(Attributes.Database.EVENT_IMG4,img4);

			if(!isEventExist(event_id)) {
				status = 0;
				cv.put(Attributes.Database.EVENT_ID, event_id);
				sqLiteDatabase.insert(Attributes.Database.EVENT_TABLE_NAME, null, cv);
			}else{
				status = 1;
				sqLiteDatabase.update(Attributes.Database.EVENT_TABLE_NAME, cv, Attributes.Database.EVENT_ID
						+ " = '" + event_id + "'", null);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return status;
	}

    //	Database methods for event insertion,updation,deletion,selection operations
    public int insertPreviousEventInDB(String event_id, String event_title, String event_sub_title, String event_desc,
                                        String event_startdate, String event_enddate, String event_is_Deleted, String event_category,
                                        String location, String img1, String img2, String img3, String img4) {

        int status = 0;
        ContentValues cv = new ContentValues();
        try {
            cv.put(Attributes.Database.EVENT_TITLE, (event_title != null ? event_title : "NA"));
            cv.put(Attributes.Database.EVENT_SUB_TITLE, (event_sub_title != null ? event_sub_title : "NA"));
            cv.put(Attributes.Database.EVENT_DESCRIPTION, (event_desc != null ? event_desc : "NA"));
            cv.put(Attributes.Database.EVENT_START_DATE, (event_startdate != null ? event_startdate : "NA"));
            cv.put(Attributes.Database.EVENT_END_DATE, (event_enddate != null ? event_enddate : "NA"));
            cv.put(Attributes.Database.EVENT_CATEGORY, (event_category != null ? event_category : "NA"));
            cv.put(Attributes.Database.EVENT_LOCATION, (location != null ? location : "NA"));
            cv.put(Attributes.Database.EVENT_IS_DELETED, event_is_Deleted);
			cv.put(Attributes.Database.EVENT_IMG1,img1);
			cv.put(Attributes.Database.EVENT_IMG2,img2);
			cv.put(Attributes.Database.EVENT_IMG3,img3);
			cv.put(Attributes.Database.EVENT_IMG4,img4);

            if(!isPreviousEventExist(event_id)) {
                status = 0;
                cv.put(Attributes.Database.EVENT_ID, event_id);
                sqLiteDatabase.insert(Attributes.Database.PREVIOUS_EVENT_TABLE_NAME, null, cv);
            }else{
                status = 1;
                sqLiteDatabase.update(Attributes.Database.PREVIOUS_EVENT_TABLE_NAME, cv, Attributes.Database.EVENT_ID
                        + " = '" + event_id + "'", null);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return status;
    }





    public Cursor getAllUpcommingEvent(String isDeleted) {
		return sqLiteDatabase.rawQuery("Select * from " + Attributes.Database.EVENT_TABLE_NAME + " where " +
				Attributes.Database.EVENT_IS_DELETED + " = ? ", new String[]
				{isDeleted});
	}


    /**
     * Function to get all previous events
     * @param deleteFlag
     * @return
     */
    public Cursor getAllPreviousEvents(String deleteFlag) {
        return sqLiteDatabase.rawQuery("Select * from " + Attributes.Database.PREVIOUS_EVENT_TABLE_NAME + " where " +
                Attributes.Database.EVENT_IS_DELETED + " = ? ", new String[]
                {deleteFlag});
    }


	public Cursor getEventById(String eventId, String action) {
        if (action.equalsIgnoreCase(Config.ACTION_UPCOMMING_EVENT))
            return sqLiteDatabase.rawQuery("Select * from " + Attributes.Database.EVENT_TABLE_NAME + " where " +
                    Attributes.Database.EVENT_ID + " = '" + eventId + "'", null);
        else
            return sqLiteDatabase.rawQuery("Select * from " + Attributes.Database.PREVIOUS_EVENT_TABLE_NAME + " where " +
                    Attributes.Database.EVENT_ID + " = '" + eventId + "'", null);
	}

    public Cursor getPreviousEventById(String id) {
        return sqLiteDatabase.rawQuery("Select * from " + Attributes.Database.PREVIOUS_EVENT_TABLE_NAME + " where " +
                Attributes.Database.EVENT_ID + " = '" + id + "'", null);
    }
    public Cursor getBranchById(String id) {
        return sqLiteDatabase.rawQuery("Select * from " + Attributes.Database.BRANCH_TABLE_NAME + " where " +
                Attributes.Database.BRANCH_ID + " = '" + id + "'", null);
    }


	public boolean isEventExist(String id) {
		boolean isExist = false;
		Cursor cursor = sqLiteDatabase.rawQuery("Select * from " + Attributes.Database.EVENT_TABLE_NAME + " where " +
				Attributes.Database.EVENT_ID + " = '" + id + "'", null);
		if (cursor != null) {
			cursor.moveToFirst();
			if (cursor.moveToFirst()) {
				do {
					if (cursor.getString(cursor.getColumnIndex(Attributes.Database.EVENT_TITLE)) != null) {
						isExist = true;
						break;
					}
				} while (cursor.moveToNext());
			}
		}
		return isExist;
	}


    public boolean isPreviousEventExist(String id) {
        boolean isExist = false;
        Cursor cursor = sqLiteDatabase.rawQuery("Select * from " + Attributes.Database.PREVIOUS_EVENT_TABLE_NAME + " where " +
                Attributes.Database.EVENT_ID + " = '" + id + "'", null);
        if (cursor != null) {
            cursor.moveToFirst();
            if (cursor.moveToFirst()) {
                do {
                    if (cursor.getString(cursor.getColumnIndex(Attributes.Database.EVENT_TITLE)) != null) {
                        isExist = true;
                        break;
                    }
                } while (cursor.moveToNext());
            }
        }
        return isExist;
    }


    /**
     * Function to check if branch exist or not
     * @param id : branch id
     * @return : availability result
     */
    public boolean isBranchExist(String id) {
        boolean isExist = false;
        Cursor cursor = sqLiteDatabase.rawQuery("Select * from " + Attributes.Database.BRANCH_TABLE_NAME + " where " +
                Attributes.Database.BRANCH_ID + " = '" + id + "'", null);
        if (cursor != null) {
            cursor.moveToFirst();
            if (cursor.moveToFirst()) {
                do {
                    if (cursor.getString(cursor.getColumnIndex(Attributes.Database.BRANCH_ADDRESS)) != null) {
                        isExist = true;
                        break;
                    }
                } while (cursor.moveToNext());
            }
        }
        return isExist;
    }


    /**
     * Method used to add branch in database
     * @param branchId
     * @param tempId
     * @param branchAddress
     * @param latitude
     * @param longitude
     * @param branchType
     * @param emailId
     * @param mobileNo
     * @param createdBy
     * @param branch_is_Deleted
     * @param createdDate
     * @param modifiedBy
     * @param modifiedDate
     * @return
     */
    public int insertBranches(String branchId,String tempId, String branchAddress,String latitude, String longitude, String branchType,
                                      String emailId, String mobileNo, String createdBy,
                                      String branch_is_Deleted,String createdDate,String modifiedBy,String modifiedDate) {

        int status = 0;
        ContentValues cv = new ContentValues();
        try {

            cv.put(Attributes.Database.BRANCH_ID, (branchId != null ? branchId : ""));
            cv.put(Attributes.Database.BRANCH_ADDRESS, (branchAddress != null ? branchAddress : "NA"));
            cv.put(Attributes.Database.LATITUDE, (latitude != null ? latitude : "NA"));
            cv.put(Attributes.Database.LONGITUDE, (longitude != null ? longitude : "NA"));
            cv.put(Attributes.Database.BRANCH_TYPE, (branchType != null ? branchType : "NA"));
            cv.put(Attributes.Database.EMAIL_ID, (emailId != null ? emailId : "NA"));
            cv.put(Attributes.Database.MOBILE_NO, (mobileNo != null ? mobileNo : "NA"));
            cv.put(Attributes.Database.CREATED_BY, (createdBy != null ? createdBy : "NA"));
            cv.put(Attributes.Database.CREATED_DATE, (createdDate != null ? createdDate : "NA"));
            cv.put(Attributes.Database.MODIFIED_BY, (modifiedBy != null ? modifiedBy : "NA"));
            cv.put(Attributes.Database.MODIFIED_DATE, (modifiedDate != null ? modifiedDate : "NA"));
            cv.put(Attributes.Database.DELETE_FLAG, branch_is_Deleted);

            String id = tempId==null ? branchId : tempId;

            if(!isBranchExist(id)) {
                status = 0;
                cv.put(Attributes.Database.BRANCH_ID, id);
                sqLiteDatabase.insert(Attributes.Database.BRANCH_TABLE_NAME, null, cv);
            }else{
                status = 1;
                sqLiteDatabase.update(Attributes.Database.BRANCH_TABLE_NAME, cv, Attributes.Database.BRANCH_ID
                        + " = '" + id + "'", null);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return status;
    }


    public Cursor getAllBranches(String isDeleted){
        return sqLiteDatabase.rawQuery("Select * from " + Attributes.Database.BRANCH_TABLE_NAME + " where " +
                Attributes.Database.DELETE_FLAG + " = ? ", new String[]
                {isDeleted});
    }



//	Database methods of master db for insertion,updation last sync timespan

	public int getMasterTableCount(){
        return sqLiteDatabase.rawQuery("Select * from "+Attributes.MasterDatabase.MASTER_TABLE, null).getCount();
	}

	public void insertTimeSpan(String event_time_span, String appInit)
	{
		ContentValues cv=new ContentValues();
		try{
			cv.put(Attributes.MasterDatabase.EVENT_TIMESPAN,event_time_span);
            cv.put(Attributes.MasterDatabase.APP_INIT_TIMESPAN,appInit);
            sqLiteDatabase.insert(Attributes.MasterDatabase.MASTER_TABLE, null, cv);
		}
		catch (Exception e) {
			e.printStackTrace();
		}

	}


    public long updateAppInitSpan(String timespan){
        long updateIndex = 0;
        ContentValues cv=new ContentValues();
        try{
            cv.put(Attributes.MasterDatabase.APP_INIT_TIMESPAN, timespan);
            updateIndex = sqLiteDatabase.update(Attributes.MasterDatabase.MASTER_TABLE,cv,null,null);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return updateIndex;
    }

	public long updateEventTimeSpan(String timespan){
		ContentValues cv=new ContentValues();
		try{
			cv.put(Attributes.MasterDatabase.EVENT_TIMESPAN, timespan);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return sqLiteDatabase.update(Attributes.MasterDatabase.MASTER_TABLE,cv,null,null);
	}

	//	Database methods for notification insertion,updation,deletion,selection operations

	public long insertNotification(String id, String type, String message, String title)
	{
		ContentValues cv=new ContentValues();
		try{
			cv.put(Attributes.Database.NOTIFICATION_ID, id);
			cv.put(Attributes.Database.NOTIFICATION_TYPE,(type!=null ? type : "NA"));
			cv.put(Attributes.Database.NOTIFICATION_MESSAGE,(message!=null ? message : "NA"));
			cv.put(Attributes.Database.NOTIFICATION_READED,"false");
			cv.put(Attributes.Database.NOTIFICATION_TITLE,title);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return sqLiteDatabase.insert(Attributes.Database.NOTIFICATION_TABLE_NAME, null, cv);
	}

	public long updateNotification(String id){
		ContentValues cv=new ContentValues();
		try{
			cv.put(Attributes.Database.NOTIFICATION_READED,"true");
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return sqLiteDatabase.update(Attributes.Database.NOTIFICATION_TABLE_NAME, cv, Attributes.Database.NOTIFICATION_ID
				+ " = '" + id + "'", null);
	}

	public int getUnreadNotificationCounts(){
		return sqLiteDatabase.rawQuery("Select * from "+Attributes.Database.NOTIFICATION_TABLE_NAME+" where "+
				Attributes.Database.NOTIFICATION_READED+" = '"+ "false" + "'",null).getCount();
	}

	public Cursor getAllNotification(){
		return sqLiteDatabase.rawQuery("Select * from "+Attributes.Database.NOTIFICATION_TABLE_NAME, null);
	}

	public int deleteAllNotifications(){
		return sqLiteDatabase.delete(Attributes.Database.NOTIFICATION_TABLE_NAME, null,null);
	}

	public long deleteSingleNotification(String id){
		return sqLiteDatabase.delete(Attributes.Database.NOTIFICATION_TABLE_NAME,Attributes.Database.NOTIFICATION_ID
				+" = '"+ id + "'",null);
	}

	public String getlastSyncdate(String status) {
		String date = "0";
		Cursor cursor = sqLiteDatabase.rawQuery("Select * from " + Attributes.MasterDatabase.MASTER_TABLE, null);
        if(cursor!=null)
			cursor.moveToFirst();
		if(cursor.moveToFirst()){
			do{
				if(status.equals(Config.APP_INIT_TIMESPAN)){
					date = cursor.getString(cursor.getColumnIndex(Attributes.MasterDatabase.APP_INIT_TIMESPAN));
				}else if (status.equalsIgnoreCase(Config.EVENT_TIMESPAN)){
                    date = cursor.getString(cursor.getColumnIndex(Attributes.MasterDatabase.EVENT_TIMESPAN));
                }
			}while (cursor.moveToNext());
		}
		return date;
	}

	/**
	 * Function used to save user profile
     * @param name
     * @param branchId
     * @param className
     * @param dob
     * @param doj
     * @param enrollmentId
     * @param fatherName
     * @param fatherNo
     * @param isDayBoarding
     * @param isVan
     * @param motherName
     * @param motherNo
     * @param permanentAddress
     * @param tempAddress
     */
	public void saveProfile(String name, String branchId, String className, long dob, long doj,
                            String enrollmentId, String fatherName, String fatherNo,
                            String isDayBoarding, String isVan, String motherName, String motherNo,
                            String permanentAddress, String tempAddress) {

        try {

            ContentValues contentValues = new ContentValues();
            contentValues.put(Attributes.Database.name,name);
            contentValues.put(Attributes.Database.BRANCH_ID,branchId);
            contentValues.put(Attributes.Database.className,className);
            contentValues.put(Attributes.Database.date_of_birth,dob);
            contentValues.put(Attributes.Database.date_of_joinning,doj);
            contentValues.put(Attributes.Database.enrollmentId,enrollmentId);
            contentValues.put(Attributes.Database.fatherName,fatherName);
            contentValues.put(Attributes.Database.fatherNo,fatherNo);
            contentValues.put(Attributes.Database.isDayBoarding,isDayBoarding);
            contentValues.put(Attributes.Database.isVan,isVan);
            contentValues.put(Attributes.Database.motherName,motherName);
            contentValues.put(Attributes.Database.motherNo,motherNo);
            contentValues.put(Attributes.Database.permanentAddress,permanentAddress);
            contentValues.put(Attributes.Database.tempAddress,tempAddress);


            if(!isProfileExists(enrollmentId)) {
                sqLiteDatabase.insert(Attributes.Database.PROFILE_TABLE_NAME, null, contentValues);
            }else{
                sqLiteDatabase.update(Attributes.Database.PROFILE_TABLE_NAME, contentValues, Attributes.Database.enrollmentId
                        + " = '" + enrollmentId + "'", null);
            }

        }catch (Exception ex){
            ex.printStackTrace();
        }


	}

    /**
     * Function used to validate for profile existance
     * @param enrollmentId
     * @return
     */
    private boolean isProfileExists(String enrollmentId) {
        boolean isExist = false;
        Cursor cursor = sqLiteDatabase.rawQuery("Select * from " + Attributes.Database.PROFILE_TABLE_NAME + " where " +
                Attributes.Database.enrollmentId + " = '" + enrollmentId + "'", null);
        if (cursor != null) {
            if (cursor.getCount() > 0)
                isExist = true;
        }
        return isExist;
    }


    /**
     * Get all user details basaed on enrollment id
     * @param enrollmentId : enrollment id of student
     * @param branchId
     * @return
     */
    public Cursor getUserDetails(String enrollmentId, String branchId){
        return sqLiteDatabase.rawQuery("Select * from "+Attributes.Database.PROFILE_TABLE_NAME +
                " where "+Attributes.Database.enrollmentId +" = '"+enrollmentId+"' and "
                +Attributes.Database.BRANCH_ID+" = '"+branchId+"'", null);
    }

    public String getBranchNameById(String branchId) {
        Cursor cursor = sqLiteDatabase.rawQuery("select "+Attributes.Database.BRANCH_ADDRESS +
                " from "+Attributes.Database.BRANCH_TABLE_NAME +
                " where "+Attributes.Database.BRANCH_ID+" = '"+branchId+"'",null);

        if (cursor != null)
            cursor.moveToFirst();

        return  cursor.getString(cursor.getColumnIndex(Attributes.Database.BRANCH_ADDRESS));

    }

    public Cursor getUserDetailsForHomework(String enrollmentId, String branchId) {
        String query = "select P."+Attributes.Database.BRANCH_ID+", P."+Attributes.Database.className+
                ", H."+Attributes.Database.homework_sync_date+" from "+Attributes.Database.PROFILE_TABLE_NAME+" p "+
                " LEFT JOIN "+Attributes.Database.HOMEWORK_TABLE_NAME+" H "+" on P."+Attributes.Database.enrollmentId+
                " = H."+Attributes.Database.enrollmentId+" where P."+Attributes.Database.enrollmentId+" = '"+enrollmentId+"'" +
                " and P."+Attributes.Database.BRANCH_ID+" = '"+branchId+"'";

        Log.d(TAG, "getHomeworks getUserDetailsForHomework: "+query);

        Cursor cursor = sqLiteDatabase.rawQuery(query,null);
        return cursor;
    }

    public void insertHomework(long lastsyncdate, String branchId, String className,
                               String homeworkDiscription, long homeworkDt, String homeworkId, String enrollmentId) {
        try {

            ContentValues contentValues = new ContentValues();
            contentValues.put(Attributes.Database.homework_sync_date,lastsyncdate);
            contentValues.put(Attributes.Database.BRANCH_ID,branchId);
            contentValues.put(Attributes.Database.className,className);
            contentValues.put(Attributes.Database.homework,homeworkDiscription);
            contentValues.put(Attributes.Database.homework_date,homeworkDt);
            contentValues.put(Attributes.Database.homeworkId,homeworkId);
            contentValues.put(Attributes.Database.enrollmentId,enrollmentId);

            if(!isHomeworkExists(homeworkId)) {
                sqLiteDatabase.insert(Attributes.Database.HOMEWORK_TABLE_NAME, null, contentValues);
            }else{
                sqLiteDatabase.update(Attributes.Database.HOMEWORK_TABLE_NAME, contentValues, Attributes.Database.homeworkId
                        + " = '" + homeworkId + "'", null);
            }

        }catch (Exception ex){
            ex.printStackTrace();
        }

    }

    /**
     * Function to validate homework status
     * @param homeworkId
     * @return
     */
    private boolean isHomeworkExists(String homeworkId) {
        boolean isExist = false;
        Cursor cursor = sqLiteDatabase.rawQuery("Select * from " + Attributes.Database.HOMEWORK_TABLE_NAME + " where " +
                Attributes.Database.homeworkId + " = '" + homeworkId + "'", null);
        if (cursor != null) {
            if (cursor.getCount() > 0)
                isExist = true;
        }
        return isExist;
    }

    /**
     * Function to get homework  based on environment id
     * @param enrollmentId : user enrollment id
     * @param branchId
     */
    public Cursor getHomeWorkbyEnrollmentId(String enrollmentId, String branchId) {
        return sqLiteDatabase.rawQuery("Select * from " + Attributes.Database.HOMEWORK_TABLE_NAME + " where " +
                Attributes.Database.enrollmentId + " = '"+enrollmentId+"' and "+
                Attributes.Database.BRANCH_ID+" = '"+branchId+"'",null);
    }

    /**
     * Function used to get class name of student based on enr id and branch
     * @param enrollmentId
     * @param branchId
     * @return
     */
    public String getClassNameOfStudent(String enrollmentId, String branchId) {
        Cursor cursor = sqLiteDatabase.rawQuery("Select * from " + Attributes.Database.PROFILE_TABLE_NAME + " where " +
                Attributes.Database.enrollmentId + " = '" + enrollmentId + "' and "+
                Attributes.Database.BRANCH_ID + " = '" + branchId+"' ", null);
        if (cursor != null) {
           cursor.moveToFirst();
           return cursor.getString(cursor.getColumnIndex(Attributes.Database.className));
        }
        return null;
    }
}
