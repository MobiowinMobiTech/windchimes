package com.mobiowin.windchim.services;

import com.mobiowin.windchim.payload.request.HomeworkRequest;
import com.mobiowin.windchim.payload.request.LoginRequest;
import com.mobiowin.windchim.payload.request.RequestIndDashboard;
import com.mobiowin.windchim.payload.request.RequestInitialData;
import com.mobiowin.windchim.payload.request.RequestSyncNotification;
import com.mobiowin.windchim.payload.request.StudentSyncNotification;
import com.mobiowin.windchim.payload.request.SubmitFeedback;
import com.mobiowin.windchim.payload.response.HomeworkResponse;
import com.mobiowin.windchim.payload.response.LoginResponse;
import com.mobiowin.windchim.payload.response.ResponseIndDashboard;
import com.mobiowin.windchim.payload.response.ResponseInitialData;
import com.mobiowin.windchim.payload.response.ResponseSyncNotification;
import com.mobiowin.windchim.payload.response.SubmitFeedbackResponse;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

public interface WindchimesServices {


    @POST("windchim/WindchimGateway")
    Call<ResponseInitialData> appSyncBanner(@Body RequestInitialData slidingBanner);

    @POST("windchim/WindchimGateway")
    Call<ResponseSyncNotification> syncNotificationId(@Body RequestSyncNotification requestSyncNotification);

    @POST("windchim/WindchimGateway")
    Call<SubmitFeedbackResponse> submitFeedback(@Body SubmitFeedback submitFeedback);

    @POST("windchim/WindchimGateway")
    Call<ResponseIndDashboard> appIndDashborad(@Body RequestIndDashboard requestIndDashboard);

    @POST("windchim/WindchimGateway")
    Call<LoginResponse> login(@Body LoginRequest loginRequest);

    @POST("windchim/WindchimGateway")
    Call<LoginResponse> syncStudentNotification(@Body StudentSyncNotification studentSyncNotification);

    @POST("windchim/WindchimGateway")
    Call<HomeworkResponse> getHomework(@Body HomeworkRequest homeworkRequest);
}
