package com.mobiowin.windchim.fragments;

import android.Manifest;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.mobiowin.windchim.R;
import com.mobiowin.windchim.activity.ActivityFragmentPlatform;
import com.mobiowin.windchim.customui.RoundedImageView;
import com.mobiowin.windchim.customui.TextViewOpenSansRegular;
import com.mobiowin.windchim.db.Attributes;
import com.mobiowin.windchim.db.DBAdapter;
import com.mobiowin.windchim.utils.CommanUtils;
import com.mobiowin.windchim.utils.PreferenceUtils;
import com.mobiowin.windchim.utils.Social;

import java.io.ByteArrayOutputStream;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import static android.app.Activity.RESULT_OK;

public class StudentProfile extends Fragment implements View.OnClickListener {
    private static final String TAG = StudentProfile.class.getSimpleName();
    private static final int CAMERA_PERMISSION_REQUEST_CODE = 99;
    private static final int STORAGE_PERMISSION_CODE = 88;
    final static int IMG_RESULT = 1;
    final int CAMERA_REQUEST = 1888;
    RoundedImageView IMG_PROFILE;
    PreferenceUtils preferenceUtils;
    String enrollnentId, branchId;
    TextViewOpenSansRegular txtEnrollmentId, txtName, txtClass, txtDOB, txtDOJ, txtDayBoarding, txtVanFacility,
            txtFatherName, txtFatherMobNo, txtMotherName, txtMotherMobNo, txtPermenentAdsress, txtTemAddress,
            txtBranch, txtProfileName;


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_student_profile, null, false);

        enrollnentId = getArguments().getString(Attributes.Database.enrollmentId);
        branchId = getArguments().getString(Attributes.Database.BRANCH_ID);
        Log.d(TAG, "okht onCreateView: "+enrollnentId);
        init(view);
        getuserProfileFromDB();


        return view;
    }

    /**
     * Function to get user details from local db
     */
    private void getuserProfileFromDB() {
        DBAdapter dbAdapter = new DBAdapter(getActivity());
        dbAdapter.open();

        Cursor cursor = dbAdapter.getUserDetails(enrollnentId,branchId);
        if(cursor!=null){
            cursor.moveToFirst();
            if(cursor.moveToFirst()){
                do{
                    txtEnrollmentId.setText(cursor.getString(cursor.getColumnIndex(Attributes.Database.enrollmentId)));
                    txtProfileName.setText(cursor.getString(cursor.getColumnIndex(Attributes.Database.name)));
                    txtClass.setText(cursor.getString(cursor.getColumnIndex(Attributes.Database.className)));


                    String date = getDate(cursor.getString(cursor.getColumnIndex(Attributes.Database.date_of_birth)));
                    String dob[] = date.split(" ");
                    String doj[] = getDate(cursor.getString(cursor.getColumnIndex(Attributes.Database.date_of_joinning)))
                            .split(" ");


                    txtDOB.setText(dob[0] + " "+dob[1]+" "+dob[2]);
                    txtDOJ.setText(doj[0] + " "+doj[1]+" "+doj[2]);

                    txtFatherName.setText(cursor.getString(cursor.getColumnIndex(Attributes.Database.fatherName)));
                    txtFatherMobNo.setText(cursor.getString(cursor.getColumnIndex(Attributes.Database.fatherNo)));
                    txtMotherName.setText(cursor.getString(cursor.getColumnIndex(Attributes.Database.motherName)));
                    txtMotherMobNo.setText(cursor.getString(cursor.getColumnIndex(Attributes.Database.motherNo)));
                    txtPermenentAdsress.setText(cursor.getString(cursor.getColumnIndex(Attributes.Database.permanentAddress)));
                    txtTemAddress.setText(cursor.getString(cursor.getColumnIndex(Attributes.Database.tempAddress)));

                    if (cursor.getString(cursor.getColumnIndex(Attributes.Database.isDayBoarding)).equalsIgnoreCase("Y"))
                        txtDayBoarding.setText("Yes");
                    else
                        txtDayBoarding.setText("No");

                    if (cursor.getString(cursor.getColumnIndex(Attributes.Database.isVan)).equalsIgnoreCase("Y"))
                        txtVanFacility.setText("Yes");
                    else
                        txtVanFacility.setText("No");

                    String branchAddress = dbAdapter.getBranchNameById(cursor.getString(cursor.getColumnIndex(Attributes.Database.BRANCH_ID)));

                    txtBranch.setText(branchAddress);


                }while (cursor.moveToNext());
            }
        }
        dbAdapter.close();

    }

    private void init(View view) {
        preferenceUtils = new PreferenceUtils(getActivity());
        IMG_PROFILE = (RoundedImageView)view.findViewById(R.id.imageview_dp_image);
        IMG_PROFILE.setOnClickListener(this);

        txtEnrollmentId = (TextViewOpenSansRegular)view.findViewById(R.id.txtEnrollmentIdValue);
        txtProfileName = (TextViewOpenSansRegular)view.findViewById(R.id.txtProfileName);
        txtClass = (TextViewOpenSansRegular)view.findViewById(R.id.txtClassValue);
        txtDOB = (TextViewOpenSansRegular)view.findViewById(R.id.txtdobValue);
        txtDOJ = (TextViewOpenSansRegular)view.findViewById(R.id.txtdojValue);
        txtDayBoarding = (TextViewOpenSansRegular)view.findViewById(R.id.txtIsDayBoardingValue);
        txtVanFacility = (TextViewOpenSansRegular)view.findViewById(R.id.txtVanFacilityValue);
        txtFatherName = (TextViewOpenSansRegular)view.findViewById(R.id.txtFatherNameValue);
        txtFatherMobNo = (TextViewOpenSansRegular)view.findViewById(R.id.txtFatherMobileNoValue);
        txtMotherName = (TextViewOpenSansRegular)view.findViewById(R.id.txtMotherNameValue);
        txtMotherMobNo = (TextViewOpenSansRegular)view.findViewById(R.id.txtMotherMobileNoValue);
        txtPermenentAdsress = (TextViewOpenSansRegular)view.findViewById(R.id.txtPAddressValue);
        txtTemAddress = (TextViewOpenSansRegular)view.findViewById(R.id.txtTemporaryAddressValue);
        txtBranch = (TextViewOpenSansRegular)view.findViewById(R.id.txtBranchValue);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.imageview_dp_image:
                uploadProfile();
                break;
        }
    }

    /**
     * Return date in specified format.
     * @param milliSeconds Date in milliseconds
     * @return String representing date in specified format
     */
    public String getDate(String milliSeconds){
        try {
            Timestamp ts = Timestamp.valueOf(syncDateparser(milliSeconds));
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd hh:mm");
            Date fechaNueva = format.parse(ts.toString());
            format = new SimpleDateFormat("dd MMM yyyy HH:mm:ss");
            return format.format(fechaNueva);
        } catch (ParseException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return "";
    }

    public String syncDateparser(String lastSyncDate) {
        long currentDateTime = Long.parseLong(lastSyncDate);
        Date currentDate = new Date(currentDateTime);

        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        String str = dateFormat.format(currentDate);

        return str;
    }



    /**
     * Function used to upload profile image
     */
    private void uploadProfile() {
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(getActivity());
        alertDialog.setTitle(" Select Profile");
        alertDialog.setPositiveButton("Camera", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                if (requestPermission(Manifest.permission.CAMERA, CAMERA_PERMISSION_REQUEST_CODE)){
                    openCameraForDP();
                }

            }
        });
        alertDialog.setNegativeButton("Gallary", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                if (requestPermission(Manifest.permission.READ_EXTERNAL_STORAGE, STORAGE_PERMISSION_CODE)){
                    openGalleryForDP();
                }
            }


        });

        alertDialog.show();
    }


    /**
     * To get permission from user
     * @param permissionName : permission to take
     * @param permissionRequestCode : request for open identifier
     * @return : status of permission
     */
    private boolean requestPermission(String permissionName, int permissionRequestCode) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
            return true;
        }
        if (getActivity().checkSelfPermission(permissionName) == PackageManager.PERMISSION_GRANTED ) {
            return true;
        } else {
            requestPermissions(new String[]{permissionName}, permissionRequestCode);
        }
        return false;
    }


    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        Log.d(TAG, "onRequestPermissionsResult: reqCode "+requestCode);

        switch (requestCode) {
            case CAMERA_PERMISSION_REQUEST_CODE: {
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED)  {
                    openCameraForDP();
                }
                return;
            }
            case STORAGE_PERMISSION_CODE:
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    openGalleryForDP();
                }
                break;

        }
    }

    /**
     * To open gallery
     */
    private void openGalleryForDP() {
        Intent intent = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, IMG_RESULT);
    }

    /**
     * To open Camera
     */
    private void openCameraForDP() {
        Intent cameraIntent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(cameraIntent, CAMERA_REQUEST);
    }



    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        String strEncodedDp;
        if (requestCode == CAMERA_REQUEST && resultCode == RESULT_OK) {
            Bitmap photo = (Bitmap) data.getExtras().get("data");
            IMG_PROFILE.setImageBitmap(photo);
            strEncodedDp = CommanUtils.encodeToBase64(CommanUtils.getSquareBitmap(photo));
            Log.d(TAG, "onActivityResult: CAMERA "+strEncodedDp);
            saveProfilePicture(photo);
        } else if (requestCode == IMG_RESULT || requestCode == IMG_RESULT) {
            try {
                if (requestCode == IMG_RESULT && resultCode == RESULT_OK
                        && null != data) {
                    Uri URI = data.getData();
                    String[] FILE = {MediaStore.Images.Media.DATA};
                    Cursor cursor = getActivity().getContentResolver().query(URI,
                            FILE, null, null, null);
                    cursor.moveToFirst();
                    int columnIndex = cursor.getColumnIndex(FILE[0]);
                    strEncodedDp = cursor.getString(columnIndex);
                    IMG_PROFILE.setImageBitmap(BitmapFactory
                            .decodeFile(strEncodedDp));

                    saveProfilePicture(BitmapFactory.decodeFile(strEncodedDp));

                    strEncodedDp = CommanUtils.encodeToBase64(CommanUtils.getSquareBitmap(BitmapFactory
                            .decodeFile(strEncodedDp)));
                    cursor.close();
                    Log.d(TAG, "onActivityResult: GALLERY "+strEncodedDp);

                }
            } catch (Exception e) {
                CommanUtils.showToast(getActivity(), "Please try again");
            }
        }
    }

    /**
     * Function to save profile picture
     * @param bitmap
     */
    private void saveProfilePicture(Bitmap bitmap) {

        ByteArrayOutputStream baos=new  ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG,100, baos);
        byte [] b=baos.toByteArray();
        String temp= Base64.encodeToString(b, Base64.DEFAULT);
        CommanUtils.saveProfilePic(getActivity(), Social.ENTITY_STUDENT, temp);

    }

    /**
     * Function to get profile image from sp
     */
    public void getProfileUpdate(){
        Bitmap profilePic = CommanUtils.getUserProfile(getActivity(), Social.ENTITY_STUDENT);
        if (profilePic != null)
            IMG_PROFILE.setImageBitmap(profilePic);
    }


    @Override
    public void onResume() {
        super.onResume();
        ActivityFragmentPlatform.changeToolbarTitleIcon(getResources().getString(R.string.profile),
                R.drawable.ic_arrow_back_black_24dp);
        getProfileUpdate();
    }
}
