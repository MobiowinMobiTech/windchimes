package com.mobiowin.windchim.utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.preference.PreferenceManager;


import com.mobiowin.windchim.payload.response.ResponseInitialData;

public class PreferenceUtils {

    private Context context;
    private SharedPreferences preferences;

    public PreferenceUtils(Context context) {
        this.context = context;
        preferences = PreferenceManager.getDefaultSharedPreferences(context);
    }

    /**
     * Function used to set banners from server
     * @param banners : banners
     */
    public void setBanners(ResponseInitialData.Bannerlist[] banners) {
        Editor editor = preferences.edit();
        editor.putString("BANNERS_SIZE" , ""+banners.length);

        for (int index = 0; index < banners.length; index++) {
            editor.putString("BANNERS"+ index, banners[index].getBannerLink());
        }
        editor.apply();
    }

    /**
     * Function used to get banner
     * @return : banner
     */
    public String getBanners() {

        String urls = "";
        int size = Integer.parseInt(preferences.getString("BANNERS_SIZE","0"));

        for (int index = 0; index < size; index++) {
            urls = (index != size -1) ? urls + preferences.getString("BANNERS"+ index,null)+"~" : urls +
                    preferences.getString("BANNERS"+ index,null);
        }
        return urls;
    }

    /**
     * Function used to get logged in status
     * @return : loggedIn status
     */
    public boolean isLoggedIn() {
        return  preferences.getBoolean("isLogin",false);
    }

    public void setLoggedInStatus(boolean status){
        Editor editor = preferences.edit();
        editor.putBoolean("isLogin",status);
        editor.apply();
    }


    public void setUserName(String name) {
        Editor editor = preferences.edit();
        editor.putString("USER_NAME", name);
        editor.commit();
    }

    public String getUserName() {
        return preferences.getString("USER_NAME", null);
    }


}
