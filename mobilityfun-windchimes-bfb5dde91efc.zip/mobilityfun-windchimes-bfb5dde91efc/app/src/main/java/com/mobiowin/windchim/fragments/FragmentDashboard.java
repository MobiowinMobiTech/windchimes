package com.mobiowin.windchim.fragments;

import android.database.Cursor;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.RequiresApi;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import com.mobiowin.windchim.R;
import com.mobiowin.windchim.activity.ActivityFragmentPlatform;
import com.mobiowin.windchim.adapter.HorizontalListVAdapter;
import com.mobiowin.windchim.adapter.SlidingImageAdapter;
import com.mobiowin.windchim.customui.TextViewOpenSansSemiBold;
import com.mobiowin.windchim.db.Attributes;
import com.mobiowin.windchim.db.DBAdapter;
import com.mobiowin.windchim.helper.CircleIndicator;
import com.mobiowin.windchim.payload.request.RequestIndDashboard;
import com.mobiowin.windchim.payload.response.ResponseIndDashboard;
import com.mobiowin.windchim.services.Device;
import com.mobiowin.windchim.services.WindchimesServices;
import com.mobiowin.windchim.utils.CommanUtils;
import com.mobiowin.windchim.utils.Config;
import com.mobiowin.windchim.utils.NetworkUtil;
import com.mobiowin.windchim.utils.PreferenceUtils;
import com.mobiowin.windchim.utils.Social;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;


public class FragmentDashboard extends Fragment  {

    private static final String TAG = FragmentDashboard.class.getSimpleName();

    private ViewPager mPager;
    private CircleIndicator mCircleIndicator;
    private String[] images;
    private Handler handler = new Handler();
    private Runnable refresh;
    private int itemPos = 0;

    private DBAdapter dbAdapter;
    private PreferenceUtils pref;

    private TextViewOpenSansSemiBold txtEventSeeMore,txtPreviousEventSeeMore ,txtBranchesSeeMore;
    private LinearLayout llEvent, llPreviousEvent, llBranches;
    private RecyclerView recycleEvent, recyclePreviousEvent, recycleBranches;

    private LinearLayoutManager layoutManagerEvent, layoutManagerPreviousEvent, layoutManagerBranches;

    private HorizontalListVAdapter eventAdapter, previousEventAdapter, branchesAdapter;

    private Cursor upcommingEventCursor, previousEventCursor, branchCursor;
    private ArrayList<String> upcommingEventList, previousEventList, branchesList;
    private ArrayList<String> upcommingEventLogo, upcomingEventIdsLists, previousEventLogo, previousEventIdsLists,
            branchesLogo, branchesIdsLists;

    private SlidingImageAdapter slidingImageAdapter;

    @RequiresApi(api = Build.VERSION_CODES.HONEYCOMB)
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_dashboard, container, false);
        init(view);
        handlingSlideShow();
        clickEventFire();

        getRetrofitCall();

        return view;
    }


    /**
     * Function to initialize view
     * @param view
     */
    private void init(View view) {

        dbAdapter = new DBAdapter(getActivity());
        pref = new PreferenceUtils(getActivity());

        mPager = (ViewPager) view.findViewById(R.id.image_pager);
        mCircleIndicator = (CircleIndicator) view.findViewById(R.id.indicator);

        recycleEvent = (RecyclerView) view.findViewById(R.id.event_recycler_view);
        recyclePreviousEvent = (RecyclerView) view.findViewById(R.id.previous_event_recycler_view);
        recycleBranches = (RecyclerView) view.findViewById(R.id.branches_recycler_view);

        llEvent = (LinearLayout) view.findViewById(R.id.llEventStatus);
        llPreviousEvent = (LinearLayout) view.findViewById(R.id.llPreviousEventStatus);
        llBranches = (LinearLayout) view.findViewById(R.id.llBranchStatus);

        txtEventSeeMore = (TextViewOpenSansSemiBold) view.findViewById(R.id.txtEventSeeMore);
        txtPreviousEventSeeMore = (TextViewOpenSansSemiBold) view.findViewById(R.id.txtPreviousEventSeeMore);
        txtBranchesSeeMore = (TextViewOpenSansSemiBold) view.findViewById(R.id.txtBranchesSeeMore);


        txtEventSeeMore = (TextViewOpenSansSemiBold) view.findViewById(R.id.txtEventSeeMore);
        txtPreviousEventSeeMore = (TextViewOpenSansSemiBold) view.findViewById(R.id.txtPreviousEventSeeMore);
        txtBranchesSeeMore = (TextViewOpenSansSemiBold) view.findViewById(R.id.txtBranchesSeeMore);

        upcommingEventList = new ArrayList<String>();
        upcommingEventLogo = new ArrayList<String>();
        upcomingEventIdsLists = new ArrayList<String>();

        previousEventList = new ArrayList<String>();
        previousEventLogo = new ArrayList<String>();
        previousEventIdsLists = new ArrayList<String>();

        branchesList = new ArrayList<String>();
        branchesLogo = new ArrayList<String>();
        branchesIdsLists = new ArrayList<String>();

        }

    @RequiresApi(api = Build.VERSION_CODES.HONEYCOMB)
    private void handlingSlideShow() {
        if(!pref.getBanners().isEmpty()){
            images = pref.getBanners().split("~");
        }else{
            images = new String[3];
            for(int i=0;i<3;i++){
                images[i] = "www.error.com";
            }
        }

        slidingImageAdapter =new SlidingImageAdapter(getActivity(), images);
        mPager.setAdapter(slidingImageAdapter);
        mCircleIndicator.setViewPager(mPager);
    }

    /**
     * Method used to add click events
     */
    private void clickEventFire() {

        txtEventSeeMore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            if(upcommingEventList.size()>0) {
                Bundle bundle = new Bundle();
                bundle.putString(Config.ACTION,Config.ACTION_UPCOMMING_EVENT);
                bundle.putString("title",getString(R.string.upcomming_event));

                FragmentViewEventAndBranches fragmentViewEvent = new FragmentViewEventAndBranches();
                fragmentViewEvent.setArguments(bundle);

                getActivity().getSupportFragmentManager().beginTransaction()
                        .replace(R.id.platform, fragmentViewEvent)
                        .addToBackStack(null).commit();
            }else{
                CommanUtils.showAlertDialog(getActivity(),getResources().getString(R.string.upcomming_event_not_found));
            }
            }
        });


        txtPreviousEventSeeMore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            if(previousEventList.size()>0) {
                Bundle bundle = new Bundle();
                bundle.putString(Config.ACTION,Config.ACTION_PREVIOUS_EVENT);
                bundle.putString("title",getString(R.string.previous_event));

                FragmentViewEventAndBranches fragmentViewEvent = new FragmentViewEventAndBranches();
                fragmentViewEvent.setArguments(bundle);

                getActivity().getSupportFragmentManager().beginTransaction()
                        .replace(R.id.platform, fragmentViewEvent)
                        .addToBackStack(null).commit();
            }else{
                CommanUtils.showAlertDialog(getActivity(),getResources().getString(R.string.previous_event_not_found));
            }
            }
        });


        txtBranchesSeeMore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            if(branchesList.size()>0) {
                Bundle bundle = new Bundle();
                bundle.putString(Config.ACTION,Config.ACTION_BRANCH);
                bundle.putString("title",getString(R.string.branches));

                FragmentViewEventAndBranches fragmentViewBranches = new FragmentViewEventAndBranches();
                fragmentViewBranches.setArguments(bundle);

                getActivity().getSupportFragmentManager().beginTransaction()
                        .replace(R.id.platform, fragmentViewBranches)
                        .addToBackStack(null).commit();
            }else{
                CommanUtils.showAlertDialog(getActivity(),getResources().getString(R.string.branches_not_found));
            }
            }
        });

    }

    public void getRetrofitCall() {
        getEventsFromServer();
    }


    /**
     * get all data from local database
     */
    public void getDataFromDBAndNotify() {

        upcommingEventList.clear();
        previousEventList.clear();
        branchesList.clear();

        upcommingEventLogo.clear();
        upcomingEventIdsLists.clear();
        previousEventLogo.clear();
        previousEventIdsLists.clear();
        branchesLogo.clear();
        branchesIdsLists.clear();

        dbAdapter.open();
        //get all upcomming events
        upcommingEventCursor = dbAdapter.getAllUpcommingEvent("F");

        if(upcommingEventCursor != null)
            upcommingEventCursor.moveToFirst();
        if(upcommingEventCursor.moveToFirst()){
            do{
                String eventImage = "";
                if (upcommingEventCursor.getString(upcommingEventCursor.getColumnIndex(Attributes.Database.EVENT_IMG1)) != null)
                    eventImage = upcommingEventCursor.getString(upcommingEventCursor.getColumnIndex(Attributes.Database.EVENT_IMG1));

                if (eventImage.equalsIgnoreCase(""))
                    if (upcommingEventCursor.getString(upcommingEventCursor.getColumnIndex(Attributes.Database.EVENT_IMG2)) != null)
                        eventImage = upcommingEventCursor.getString(upcommingEventCursor.getColumnIndex(Attributes.Database.EVENT_IMG2));

                if (eventImage.equalsIgnoreCase(""))
                    if (upcommingEventCursor.getString(upcommingEventCursor.getColumnIndex(Attributes.Database.EVENT_IMG3))
                             != null)
                        eventImage = upcommingEventCursor.getString(upcommingEventCursor.getColumnIndex(Attributes.Database.EVENT_IMG3));

                if (eventImage.equalsIgnoreCase(""))
                    if (upcommingEventCursor.getString(upcommingEventCursor.getColumnIndex(Attributes.Database.EVENT_IMG4))
                             != null)
                        eventImage = upcommingEventCursor.getString(upcommingEventCursor.getColumnIndex(Attributes.Database.EVENT_IMG4));

                upcommingEventLogo.add(eventImage);
                upcommingEventList.add(upcommingEventCursor.getString(
                        upcommingEventCursor.getColumnIndex(Attributes.Database.EVENT_TITLE)));
                upcomingEventIdsLists.add(upcommingEventCursor.getString(
                        upcommingEventCursor.getColumnIndex(Attributes.Database.EVENT_ID)));
            }while (upcommingEventCursor.moveToNext());
        }


        //get all previous events
        previousEventCursor = dbAdapter.getAllPreviousEvents("F");

        if(previousEventCursor != null)
            previousEventCursor.moveToFirst();
        if(previousEventCursor.moveToFirst()){
            do{
                String eventImage = "";
                if (previousEventCursor.getString(previousEventCursor.getColumnIndex(Attributes.Database.EVENT_IMG1))
                         != null)
                    eventImage = previousEventCursor.getString(previousEventCursor.getColumnIndex(Attributes.Database.EVENT_IMG1));

                if (eventImage.equalsIgnoreCase(""))
                    if (previousEventCursor.getString(previousEventCursor.getColumnIndex(Attributes.Database.EVENT_IMG2))
                             != null)
                        eventImage = previousEventCursor.getString(previousEventCursor.getColumnIndex(Attributes.Database.EVENT_IMG2));

                if (eventImage.equalsIgnoreCase(""))
                    if (previousEventCursor.getString(previousEventCursor.getColumnIndex(Attributes.Database.EVENT_IMG3))
                             != null)
                        eventImage = previousEventCursor.getString(previousEventCursor.getColumnIndex(Attributes.Database.EVENT_IMG3));

                if (eventImage.equalsIgnoreCase(""))
                    if (previousEventCursor.getString(previousEventCursor.getColumnIndex(Attributes.Database.EVENT_IMG4))
                             != null)
                        eventImage = previousEventCursor.getString(previousEventCursor.getColumnIndex(Attributes.Database.EVENT_IMG4));

                previousEventLogo.add(eventImage);
                previousEventList.add(previousEventCursor.getString(
                        previousEventCursor.getColumnIndex(Attributes.Database.EVENT_TITLE)));
                previousEventIdsLists.add(previousEventCursor.getString(
                        previousEventCursor.getColumnIndex(Attributes.Database.EVENT_ID)));
            }while (previousEventCursor.moveToNext());
        }

        //get all branches events
        branchCursor = dbAdapter.getAllBranches("F");

        if(branchCursor != null)
            branchCursor.moveToFirst();
        if(branchCursor.moveToFirst()){
            do{
                branchesLogo.add(Config.LOCAL_LOGO);
                branchesList.add(getString(R.string.app_name));
                branchesIdsLists.add(branchCursor.getString(
                        branchCursor.getColumnIndex(Attributes.Database.BRANCH_ID)));
            }while (branchCursor.moveToNext());
        }

        dbAdapter.close();

        // set data to recycler view
        recycleEvent.setHasFixedSize(true);
        layoutManagerEvent = new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL, false);
        recycleEvent.setLayoutManager(layoutManagerEvent);
        eventAdapter = new HorizontalListVAdapter(getActivity(), upcommingEventLogo,upcommingEventList,
                upcomingEventIdsLists,R.drawable.events, Social.NAVIGATE_TO_EVENT);
        recycleEvent.setAdapter(eventAdapter);


        recyclePreviousEvent.setHasFixedSize(true);
        layoutManagerPreviousEvent = new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL, false);
        recyclePreviousEvent.setLayoutManager(layoutManagerPreviousEvent);
        previousEventAdapter = new HorizontalListVAdapter(getActivity(), previousEventLogo,previousEventList,
                previousEventIdsLists,R.drawable.events, Social.NAVIGATE_TO_PREVIOUS_EVENT);
        recyclePreviousEvent.setAdapter(previousEventAdapter);

        recycleBranches.setHasFixedSize(true);
        layoutManagerBranches = new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL, false);
        recycleBranches.setLayoutManager(layoutManagerBranches);
        branchesAdapter = new HorizontalListVAdapter(getActivity(), branchesLogo,branchesList,
                branchesIdsLists,R.drawable.events, Social.NAVIGATE_TO_BRANCHES);
        recycleBranches.setAdapter(branchesAdapter);


        if(upcommingEventList.size()>0){
            recycleEvent.setVisibility(View.VISIBLE);
            llEvent.setVisibility(View.GONE);
        }else{
            recycleEvent.setVisibility(View.GONE);
            llEvent.setVisibility(View.VISIBLE);
        }

        if(previousEventList.size()>0){
            recyclePreviousEvent.setVisibility(View.VISIBLE);
            llPreviousEvent.setVisibility(View.GONE);
        }else{
            recyclePreviousEvent.setVisibility(View.GONE);
            llPreviousEvent.setVisibility(View.VISIBLE);
        }

        if(branchesList.size()>0){
            recycleBranches.setVisibility(View.VISIBLE);
            llBranches.setVisibility(View.GONE);
        }else{
            recycleBranches.setVisibility(View.GONE);
            llBranches.setVisibility(View.VISIBLE);
        }

    }

    /**
     * Method used to get event from server
     */
    public void getEventsFromServer(){
        if (NetworkUtil.isInternetConnected(getActivity())) {

            CommanUtils.showDialog(getActivity());
            Device.newInstance(getActivity());

            dbAdapter.open();
            RequestIndDashboard reqIndDash = RequestIndDashboard.get("",dbAdapter.getlastSyncdate(Config.EVENT_TIMESPAN));
            dbAdapter.close();

            Retrofit mRetrofit = NetworkUtil.getRetrofit();
            WindchimesServices windchimesServices = mRetrofit.create(WindchimesServices.class);

            Call<ResponseIndDashboard> resSyncEventCall = windchimesServices.appIndDashborad(reqIndDash);

            resSyncEventCall.enqueue(new Callback<ResponseIndDashboard>() {
                @Override
                public void onResponse(Call<ResponseIndDashboard> call, Response<ResponseIndDashboard> response) {
                    if (response.isSuccessful()) {
                        if (response.body().getStatus().equals("success")) {
                            insertDataIntoDB(response);
                        }
                    } else if (response.body() == null) {
                        CommanUtils.showToast(getActivity(), getResources().getString(R.string.error_server));
                    }
                    CommanUtils.hideDialog();

                }

                @Override
                public void onFailure(Call<ResponseIndDashboard> call, Throwable t) {
                    CommanUtils.hideDialog();
                    CommanUtils.showToast(getActivity(), getResources().getString(R.string.error_timeout));
                }
            });
        } else {
            CommanUtils.showAlertDialog(getActivity(),getResources().getString(R.string.error_internet));
        }

    }

    /**
     * Function to insert data into table
     * @param response : response from server
     */
    private void insertDataIntoDB(Response<ResponseIndDashboard> response){

        dbAdapter = new DBAdapter(getActivity());
        dbAdapter.open();

        for (int i = 0; i < response.body().getData()[0].getEventlist().length; i++) {
            ResponseIndDashboard.Eventlist event = response.body().getData()[0].getEventlist()[i];
            if (event.getEventType().equalsIgnoreCase("previous")){

                dbAdapter.insertPreviousEventInDB(event.getEventId(),event.getTitle(),event.getSubTitle(),event.getDiscription(),
                        event.getStartDt(),event.getEndDt(),event.getDeleteFlag(),event.getCategory(),event.getLocation(),
                        event.getImg1(),event.getImg2(),event.getImg3(),event.getImg4());
            }else {
                dbAdapter.insertUpcommingEventInDB(event.getEventId(),event.getTitle(),event.getSubTitle(),event.getDiscription(),
                        event.getStartDt(),event.getEndDt(),event.getDeleteFlag(),event.getCategory(),event.getLocation(),
                        event.getImg1(),event.getImg2(),event.getImg3(),event.getImg4());            }
        }


        dbAdapter.updateEventTimeSpan(response.body().getMessage());
        dbAdapter.close();
        getDataFromDBAndNotify();
    }


    public void initializeTimer(){

        itemPos = mPager.getCurrentItem();
        if(handler!=null){
            handler.removeCallbacks(refresh);
        }

        handler = new Handler();

        refresh = new Runnable() {
            public void run() {
                if (mPager.getCurrentItem() < images.length-1) {
                    mPager.setCurrentItem(itemPos, true);
                    itemPos = itemPos + 1;
                  }else{
                    itemPos = 0;
                    mPager.setCurrentItem(itemPos, true);
                }
                handler.postDelayed(refresh, 4000);
            }
        };
        handler.post(refresh);
    }


    @Override
    public void onResume() {
        super.onResume();
        ActivityFragmentPlatform.changeToolbarTitleIcon(getResources().getString(R.string.dash_borad),
                R.drawable.ic_menu_black_24dp);
        // existing data
        getDataFromDBAndNotify();
        // slider image timmer
        initializeTimer();
    }

}


