package com.mobiowin.windchim.fragments;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.mobiowin.windchim.R;
import com.mobiowin.windchim.activity.ActivityFragmentPlatform;
import com.mobiowin.windchim.customui.TextViewOpenSansRegular;

public class FragmentFacilities extends Fragment {

    String[] facilities;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_facilities, container, false);


        facilities = getActivity().getResources().getStringArray(R.array.facilities);

        // display facilities
        ListView facilityList = (ListView)view.findViewById(R.id.facilityList);
        facilityList.setAdapter(new CustomListAdapter(getActivity(),0));

        return view;
    }


    @Override
    public void onResume() {
        super.onResume();
        ActivityFragmentPlatform.changeToolbarTitleIcon(getResources().getString(R.string.facilities),
                R.drawable.ic_arrow_back_black_24dp);
    }

    private class CustomListAdapter extends ArrayAdapter<String> {
        private Context context;

        public CustomListAdapter(Context context, int resource) {
            super(context, resource);
            this.context = context;
        }

        @Override
        public int getCount() {
            return facilities.length;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            CustomListAdapter.ViewHolder viewHolder = new CustomListAdapter.ViewHolder();

            if(convertView==null){
                LayoutInflater layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                convertView = layoutInflater.inflate(R.layout.fragment_custom_facility,null);
                viewHolder.txtFacility = (TextViewOpenSansRegular) convertView.findViewById(R.id.txtFacilityName);
                convertView.setTag(viewHolder);
            }else{
                viewHolder = (CustomListAdapter.ViewHolder) convertView.getTag();
            }

            viewHolder.txtFacility.setText(facilities[position]);

            return convertView;
        }


        class ViewHolder {
            TextViewOpenSansRegular txtFacility;
        }


    }
}
