package com.moboiowin;

public class Account {

	private String account;
	private String name;
	private String amount;

	public Account(String account, String name, String amount) {
		super();
		this.account = account;
		this.name = name;
		this.amount = amount;
	}

	public String getAccount() {
		return account;
	}

	public void setAccount(String account) {
		this.account = account;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	@Override
	public String toString() {
		return "Account [account=" + account + ", name=" + name + ", amount=" + amount + "]";
	}

	
	
}
