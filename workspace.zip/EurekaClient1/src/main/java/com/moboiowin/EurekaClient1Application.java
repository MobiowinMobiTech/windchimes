package com.moboiowin;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
@EnableDiscoveryClient
@RestController
public class EurekaClient1Application {

	public static void main(String[] args) {
		new SpringApplicationBuilder(EurekaClient1Application.class).web(true).run(args);
	}

	@RequestMapping("/greeting")
	public String greeting() {
		return "Hello from EurekaClient!";
	}
}
